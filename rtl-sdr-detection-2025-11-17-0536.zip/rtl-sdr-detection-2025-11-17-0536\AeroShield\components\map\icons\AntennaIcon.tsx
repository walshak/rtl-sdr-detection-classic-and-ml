import { AntennaData } from "@/types/signal";
import L from "leaflet";

// Create antenna icon
export const createAntennaIcon = (
  antenna: AntennaData,
  isSelected: boolean,
) => {
  const statusColor =
    antenna.status === "active"
      ? "#22c55e"
      : antenna.status === "maintenance"
        ? "#eab308"
        : "#ef4444";
  const size = isSelected ? antenna.size * 1.5 : antenna.size;

  return L.divIcon({
    className: "antenna-marker",
    html: `
        <div style="position: relative; width: ${size}px; height: ${size}px;">
          <!-- Professional antenna tower icon with background -->
          <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" style="filter: drop-shadow(0 2px ${isSelected ? "8px" : "4px"} rgba(0,0,0,0.3));">
            <!-- White border circle -->
            <circle cx="12" cy="12" r="11" fill="white"/>
            
            <!-- Red background circle -->
            <circle cx="12" cy="12" r="9" fill="#ef4444"/>
            
            <!-- Tower base -->
            <path d="M10 18h4v2h-4z" fill="white"/>
            
            <!-- Tower structure -->
            <path d="M11 10v8h2v-8z" fill="white"/>
            
            <!-- Tower top platform -->
            <rect x="9" y="9" width="6" height="1.5" rx="0.5" fill="white"/>
            
            <!-- Signal waves -->
            <path d="M8 10c0-2.2 1.8-4 4-4s4 1.8 4 4" 
                  stroke="white" 
                  stroke-width="1.2" 
                  stroke-linecap="round" 
                  fill="none"
                  opacity="${isSelected ? "0.8" : "0.5"}"/>
            <path d="M9.5 10c0-1.4 1.1-2.5 2.5-2.5s2.5 1.1 2.5 2.5" 
                  stroke="white" 
                  stroke-width="1.2" 
                  stroke-linecap="round" 
                  fill="none"
                  opacity="${isSelected ? "0.9" : "0.6"}"/>
            
            <!-- Antenna tip -->
            <circle cx="12" cy="6.5" r="1" fill="white"/>
            <path d="M12 5.5V4" stroke="white" stroke-width="1.2" stroke-linecap="round"/>
          </svg>
          
          ${
            isSelected
              ? `
            <div style="
              position: absolute;
              top: 50%;
              left: 50%;
              transform: translate(-50%, -50%);
              width: ${size * 1.8}px;
              height: ${size * 1.8}px;
              border: 2px solid ${statusColor};
              border-radius: 50%;
              animation: pulse-antenna 1.5s infinite;
            "></div>
          `
              : ""
          }
          
          <!-- Antenna label -->
          <div style="
            position: absolute;
            top: ${size + 2}px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0,0,0,0.8);
            color: white;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: bold;
            white-space: nowrap;
            box-shadow: 0 1px 3px rgba(0,0,0,0.3);
          ">${antenna.name}</div>
        </div>
      `,
    iconSize: [size, size + 20],
    iconAnchor: [size / 2, size],
  });
};
