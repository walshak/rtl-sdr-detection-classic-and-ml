import Overwatch from "@/components/Overwatch";
export default function OverwatchDashboardPage() {
  return (
    <main className="flex min-h-screen flex-col gap-5 items-center ">
      {/* <h1 className="text-3xl font-bold mb-4">AeroShield Dashboard</h1>
      <MapClient /> */}
      <Overwatch />
    </main>
  );
}
