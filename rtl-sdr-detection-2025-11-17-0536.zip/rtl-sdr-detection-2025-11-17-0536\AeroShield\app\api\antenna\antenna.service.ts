import { prisma } from "@/lib/prisma";
import { PaginateQueryParams, PaginateService } from "@/util/paginate";
import { Prisma } from "@prisma/client";

export class AntennaService {
  private paginateService = new PaginateService();

  async create(data: Prisma.AntennaCreateInput) {
    try {
      return await prisma.antenna.create({ data });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError) {
        // Unique constraint violation (code 'P2002')
        if (error.code === "P2002") {
          throw new Error(
            `A PaidRequest with this ${error.meta?.target} already exists.`,
          );
        }
      }
      throw error; // Re-throw other errors
    }
  }

  async findAll(query?: PaginateQueryParams) {
    const AntennaModel = prisma.antenna;
    if (query) {
      return await this.paginateService.paginate(AntennaModel, query);
    }
    return prisma.antenna.findMany();
  }

  async findById(id: string) {
    return await prisma.antenna.findUnique({ where: { id } });
  }

  async update(id: string, data: Prisma.AntennaUpdateInput) {
    return await prisma.antenna.update({ where: { id }, data });
  }

  async delete(id: string) {
    return await prisma.antenna.delete({ where: { id } });
  }
}
