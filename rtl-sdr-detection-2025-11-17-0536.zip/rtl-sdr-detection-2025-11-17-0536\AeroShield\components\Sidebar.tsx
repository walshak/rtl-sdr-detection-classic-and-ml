"use client";

import { RxDashboard } from "react-icons/rx";
import { MdOutlineAdd, MdOutlineLogout } from "react-icons/md";
import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { useWindowResizer } from "@/hooks/UseWindowResize";
import Link from "next/link";
import { CiSquareChevLeft, CiSquareChevRight } from "react-icons/ci";
import { Cog, SatelliteDish, ScanEye } from "lucide-react";
import { toast } from "react-toastify";
import { useSidebar } from "@/hooks/SidebarContex";
import Cookies from "js-cookie";

export default function Sidebar() {
  const router = useRouter();
  const { windowWidth, isMobile } = useWindowResizer();
  const { isSidebarOpen, setIsSidebarOpen } = useSidebar();
  const pathname = usePathname();
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const userData = Cookies.get("user");
    if (userData) {
      setUser(JSON.parse(userData));
    }
  }, []);
  useEffect(() => {
    const checkIfMobile = () => {
      if (isMobile) {
        setIsSidebarOpen(false);
      } else {
        // Don't force open on larger screens to allow toggle functionality
        // But set it open initially if it wasn't explicitly closed
        if (isSidebarOpen === undefined) {
          setIsSidebarOpen(true);
        }
      }
    };

    // Initial check
    checkIfMobile();

    // Add event listener for window resize
    window.addEventListener("resize", checkIfMobile);

    // Cleanup event listener
    return () => window.removeEventListener("resize", checkIfMobile);
  }, [windowWidth]);

  const toggleSidebar = () => {
    setIsSidebarOpen(
      typeof isSidebarOpen === "boolean" ? !isSidebarOpen : false,
    );
  };

  // Function to check if a link is active for root (/admin) dashboard
  const isActiveLink = (path: string) => {
    // Check if the current path matches the link's path
    return pathname === path;
  };

  const handleLogout = async () => {
    try {
      const response = await fetch("/api/auth/logout", {
        method: "GET",
      });

      if (response.ok) {
        Cookies.remove("user");
        toast.success("Logout successful!");
        router.push("/");
      } else {
        const errorData = await response.json();
        toast.error(errorData.error || "Logout failed. Please try again.");
      }
    } catch (error) {
      toast.error("An unexpected error occurred. Please try again.");
    }
  };

  const Links = [
    { to: "/", label: "Dashboard", icon: <RxDashboard size={16} /> },
    { to: "/overwatch", label: "Overwatch", icon: <ScanEye size={16} /> },
    { to: "/antennas", label: "Antenas", icon: <SatelliteDish size={16} /> },
    { to: "/settings", label: "Settings", icon: <Cog size={16} /> },
  ];
  return (
    <>
      {/* Overlay - shown only when sidebar is open on mobile */}
      {isMobile && isSidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-20"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Toggle button for when sidebar is closed (both mobile and desktop) */}
      {!isSidebarOpen && (
        <button
          className="fixed top-4 left-1 z-30 p-1 bg-cyan-600 text-white rounded-md shadow-md flex items-center justify-center"
          onClick={toggleSidebar}
        >
          <CiSquareChevRight size={30} />
        </button>
      )}

      {/* Main sidebar */}
      <aside
        className={`${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        } fixed md:fixed h-full z-30 w-64 overflow-y-auto flex flex-col px-4 py-5 gap-y-2 border-r border-r-gray-600 bg-gray-900 transition-transform duration-300 ease-in-out`}
      >
        <div className="flex justify-end items-center">
          {/* <img className="h-[45px] w-fit" src={logo} alt="logo" /> */}

          <button
            className={`w-fit  transform bg-cyan-600 text-white p-1 cursor-pointer rounded-md hover:bg-cyan-700 transition-all`}
            onClick={toggleSidebar}
          >
            <CiSquareChevLeft size={30} />
          </button>
        </div>

        <div className="flex flex-col gap-7 flex-1 w-full h-[70%] mt-5 ">
          {/* Map through navigation links */}

          {Links.map((link) => (
            <Link
              key={link.to}
              href={`/dashboard${link.to === "/" ? "" : link.to}`}
              className={`${
                isActiveLink(`/dashboard${link.to === "/" ? "" : link.to}`)
                  ? "text-white bg-cyan-600 hover:bg-cyan-700"
                  : "text-gray-300  hover:bg-gray-800"
              } rounded-[8px] p-2.5 px-3 flex items-center gap-x-3 text-sm w-full`}
              onClick={() => isMobile && setIsSidebarOpen(false)}
            >
              <span className="transition-none flex-shrink-0">{link.icon}</span>
              <span className="line-clamp-1">{link.label}</span>
            </Link>
          ))}

          {user?.role === "ADMIN" && (
            <Link
              href={"/dashboard/create-user"}
              className={`${
                isActiveLink(`/dashboard/create-user`)
                  ? "text-white bg-cyan-600 hover:bg-cyan-700"
                  : "text-gray-300  hover:bg-gray-800"
              } rounded-[8px] p-2.5 px-3 flex items-center gap-x-3 text-sm w-full`}
              onClick={() => isMobile && setIsSidebarOpen(false)}
            >
              <span className="transition-none flex-shrink-0">
                <MdOutlineAdd size={16} />
              </span>
              <span className="line-clamp-1">Create User</span>
            </Link>
          )}

          {/* Logout button */}
          <button
            className="w-full flex items-center gap-x-3 p-3 rounded-lg hover:bg-red-600/10 text-sm text-red-500 mt-10"
            onClick={handleLogout}
          >
            <MdOutlineLogout size={16} color="crimson" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Main content padding adjustment for when sidebar is open on desktop */}
      {!isMobile && isSidebarOpen && <div className="w-64"></div>}
    </>
  );
}
