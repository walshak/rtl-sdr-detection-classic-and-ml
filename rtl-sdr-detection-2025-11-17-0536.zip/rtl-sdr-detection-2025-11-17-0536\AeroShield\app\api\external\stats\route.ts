import { NextResponse } from "next/server";

export async function GET() {
  try {
    // Simulate fetching statistics data

    const response = await fetch(`${process.env.API_BASE_URL}/statistics`);
    const stats = await response.json();
    return NextResponse.json({
      message: "Statistics successfully retrieved",
      data: stats,
      success: true,
    });
  } catch (error) {
    return NextResponse.json(
      {
        message: `Error fetching statistics, please try again later`,
        error: (error as Error).message,
      },
      { status: 500 },
    );
  }
}
