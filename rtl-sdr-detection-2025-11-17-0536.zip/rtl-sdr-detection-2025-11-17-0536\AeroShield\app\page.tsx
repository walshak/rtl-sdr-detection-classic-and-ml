import SignInForm from "@/components/Auth/SignInForm";

export default function Home() {
  return (
    <div className=" bg-[url('/images/bg_image.webp')] bg-cover bg-center h-screen  flex items-center justify-center ">
      <div className=" bg-[#1E1E1E99] p-4 rounded-lg border border-gray-700 mt-16 max-w-[400px] w-[90%]  shadow-lg">
        <SignInForm />
      </div>
    </div>
  );
}
