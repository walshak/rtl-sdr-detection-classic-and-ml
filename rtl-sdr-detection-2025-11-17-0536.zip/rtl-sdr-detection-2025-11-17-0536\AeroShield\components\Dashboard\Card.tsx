export const Card = ({
  title,
  content,
  icon,
}: {
  title: string;
  content: string;
  icon: React.ReactNode;
}) => {
  return (
    <div className="bg-gray-900 p-6 flex flex-col items-center justify-center rounded-3xl border border-cyan-500/30 shadow-lg">
      <div className="text-white mb-4">{icon}</div>
      <h3 className="font-semibold text-lg">{title}</h3>
      <p className="text-sm text-gray-400">{content}</p>
    </div>
  );
};
