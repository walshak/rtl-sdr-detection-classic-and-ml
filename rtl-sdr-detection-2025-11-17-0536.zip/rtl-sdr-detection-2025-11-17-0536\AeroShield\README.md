# Aeroshield Visualizer

This is the web visualiser for RF signals across multiple bands.

## 🛠️ Installation & Setup

### 1. Clone the repository

```bash
git clone https://github.com/Mikkybeardless/AeroShield.git
```

### 2. Install Dependencies

```bash
npm install
npx prisma generate
```

### 3. Setup Environmental variables

creat a `.env` file or `.env.example` file in the project root directory

```plaintext
DATABASEURL= <your db url>
JWT_SECRET=<your jwt secret>
API_BASE_URL=<your baseurl>
```

### STart the Developmet Server

```bash
npm run dev
```
