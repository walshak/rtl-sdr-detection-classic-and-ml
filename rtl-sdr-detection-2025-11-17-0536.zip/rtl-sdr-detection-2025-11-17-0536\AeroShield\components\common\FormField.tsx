const FormField: React.FC<FormFieldProps> = ({
  type,
  placeholder,
  name,
  register,
  error,
  valueAsNumber,
}) => (
  <>
    <div className="flex gap-2 w-full">
      {/* <label htmlFor={name}>{placeholder}</label> */}
      <input
        type={type}
        className="text-black border-gray-300 border  rounded px-3 py-2 w-full"
        placeholder={placeholder}
        {...register(name, { valueAsNumber })}
      />
    </div>
    {error && <span className="error-message">{error.message}</span>}
  </>
);
export default FormField;
