// types/signals.ts
export interface Coordinates {
  lat: number;
  lng: number;
}

export interface AntennaData {
  id: number;
  name: string;
  lat: number;
  lng: number;
  size: number; // in meters
  coverage_radius: number; // in km
  direction: number; // bearing in degrees (0-360)
  coverage_angle: number; // sector angle in degrees (e.g., 120 for 120° sector)
  // type: "VHF" | "UHF" | "GSM" | "UAV";
  status: "active" | "inactive" | "maintenance";
}

export interface SignalData {
  id: number;
  frequency: number;
  strength: string;
  snr: string;
  type: "VHF" | "UHF" | "GSM" | "UAV";
  modulation: "FM" | "AM";
  bandwidth: string;
  duration: number;
  bearing: number;
  distance: number;
  lat: number;
  lng: number;
  timestamp: Date;
  detectedByAntennaId?: number;
}

type Label =
  | "wfm"
  | "gsm_nigeria_900"
  | "walkie_pmr446"
  | "tv"
  | "walkie_vhf"
  | "walkie_uhf";
export interface Detection {
  bandwidth: number;
  freq: number;
  id: number;
  label: Label;
  peak_power: number;
  power_spectrum: number[];
  snr: number;
  timestamp: string;
}

export interface Alert {
  id: number;
  message: string;
  severity: "high" | "medium" | "low";
  time: string;
}

export interface APIResponse {
  objects?: SignalData[];
  vhfSignals?: SignalData[];
  uhfSignals?: SignalData[];
  gsmSignals?: SignalData[];
}

export interface SignalMetricLength {
  vhfLength: number;
  uhfLength: number;
  gsmLength: number;
}
