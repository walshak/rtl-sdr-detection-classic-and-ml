import { NextRequest, NextResponse } from "next/server";

export function middleware(request: NextRequest) {
  const token = request.cookies.get("token")?.value;

  if (!token) {
    const loginUrl = new URL("/", request.url);
    return NextResponse.redirect(loginUrl);
  }

  const url = new URL(request.url);
  console.log("Middleware accessed for URL:", url.pathname);

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*"], // Protects dashboard routes
};
