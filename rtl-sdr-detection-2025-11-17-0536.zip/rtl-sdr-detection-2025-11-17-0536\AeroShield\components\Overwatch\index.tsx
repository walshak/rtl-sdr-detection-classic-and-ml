"use client";

import { Activity, Radio, AlertTriangle } from "lucide-react";
import React, { useState, useEffect, useMemo } from "react";
import dynamic from "next/dynamic";
import { MapPin, RefreshCw } from "lucide-react";
import { MetricCard } from "./MetricCard";
import { WaterfallDisplay } from "./WaterfallDisplay";
import { SignalList } from "./SignalList";
import { AlertPanel } from "./AlertPanel";
import { ObjectDetails } from "./ObjectDetails";
import {
  Alert,
  AntennaData,
  Detection,
  SignalData,
  SignalMetricLength,
} from "@/types/signal";
import {
  generateAntenna,
  generateRealSignal,
  generateSignal,
  generateWaterfallLine,
  getAntennaByName,
  getCountByLabel,
} from "@/util/helper";
import { useSidebar } from "@/hooks/SidebarContex";
import { BsArrowsFullscreen, BsFullscreenExit } from "react-icons/bs";
import { SiBaremetrics } from "react-icons/si";
import { MdZoomOutMap } from "react-icons/md";
import {
  generateMetricList,
  generateSignalList,
  generateWaterfallList,
} from "@/config/overview";
import { get } from "http";

const SignalMap = dynamic(() => import("../map/SignalMap"), {
  loading: () => <p className="text-xl h-full text-center">loading map...</p>,
  ssr: false,
});

const UHFVHFDashboard: React.FC = () => {
  const [vhfSignals, setVhfSignals] = useState<SignalData[]>([]);
  const [uhfSignals, setUhfSignals] = useState<SignalData[]>([]);
  const [gsmSignals, setGsmSignals] = useState<SignalData[]>([]);
  const [metricLength, setMetricLength] = useState<SignalMetricLength>({
    vhfLength: 0,
    uhfLength: 0,
    gsmLength: 0,
  });
  // const [uavSignals, setUavSignals] = useState<SignalData[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [waterfallVHF, setWaterfallVHF] = useState<number[][]>([]);
  const [waterfallUHF, setWaterfallUHF] = useState<number[][]>([]);
  const [waterfallGSM, setWaterfallGSM] = useState<number[][]>([]);
  // const [waterfallUAV, setWaterfallUAV] = useState<number[][]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [detectedObjects, setDetectedObjects] = useState<SignalData[]>([]);
  const [time, setTime] = useState<Date>(new Date());
  const [selectedObject, setSelectedObject] = useState<SignalData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [largeView, setLargeView] = useState<boolean>(false);
  const [antennas, setAntennas] = useState<AntennaData[]>([]);
  const [selectedAntenna, setSelectedAntenna] = useState<AntennaData | null>(
    null,
  );
  const [mapMode, setMapMode] = useState<boolean>(false);

  const { isSidebarOpen } = useSidebar();

  // const API_ENDPOINT = "http://127.0.0.1:5000"; // Replace with your actual API endpoint
  const fetchDataFromAPI = async (): Promise<void> => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/external/device`);
      const data = await response.json();
      // console.log("Fetched data:", data);

      // if (data.objects) {
      //   setDetectedObjects(data.objects);
      // }
      // if (data.vhfSignals) {
      //   setVhfSignals(data.vhfSignals);
      // }
      // if (data.uhfSignals) {
      //   setUhfSignals(data.uhfSignals);
      // }
      // if (data.gsmSignals) {
      //   setGsmSignals(data.gsmSignals);
      // }
    } catch (error) {
      console.error("Error fetching data:", error);
      // generateSimulatedData();
    } finally {
      setIsLoading(false);
    }
  };

  const fetchStatsFromAPI = async (): Promise<void> => {
    try {
      const response = await fetch(`/api/external/stats`);
      const data = await response.json();
      // console.log("Fetched stats:", data);
      setStats(data.data);
      // Process and set stats data as needed
    } catch (error) {
      console.error("Error fetching stats:", error);
    }
  };
  const fetchDetectedObjectsFromAPI = async (): Promise<void> => {
    try {
      const response = await fetch(
        `/api/external/detections?device_label=DEVICE_1`,
      );
      const data = await response.json();
      const detections = data.data.results;
      const objects: SignalData[] = detections.map((detection: Detection) => {
        if (detection.label === "walkie_vhf") {
          setVhfSignals((prev) =>
            [
              ...prev,
              generateRealSignal(
                detection,
                "VHF",
                detection.label === "wfm" ? "FM" : "AM",
                getAntennaByName("DEVICE_1", antennas) || antennas[0],
              ),
            ].slice(-8),
          );
        }

        if (detection.label === "walkie_uhf") {
          setUhfSignals((prev) =>
            [
              ...prev,
              generateRealSignal(
                detection,
                "UHF",
                detection.label === "wfm" ? "FM" : "AM",
                getAntennaByName("DEVICE_1", antennas) || antennas[0],
              ),
            ].slice(-8),
          );
        }

        if (detection.label === "gsm_nigeria_900") {
          setGsmSignals((prev) =>
            [
              ...prev,
              generateRealSignal(
                detection,
                "GSM",
                detection.label === "wfm" ? "FM" : "AM",
                getAntennaByName("DEVICE_1", antennas) || antennas[0],
              ),
            ].slice(-8),
          );
        }

        if (detection.freq > 1000000) {
          const newAlert: Alert = {
            id: Date.now(),
            message: `High power signal detected at ${(detection.freq / 1000000).toFixed(1)} MHz`,
            severity: detection.freq > 1500000 ? "high" : "medium",
            time: new Date().toLocaleTimeString(),
          };
          setAlerts((prev) => [newAlert, ...prev].slice(0, 10));
        }

        return generateRealSignal(
          detection,
          detection.freq < 300 ? "VHF" : detection.freq < 3000 ? "UHF" : "GSM",
          detection.label === "wfm" ? "FM" : "AM",
          getAntennaByName("DEVICE_1", antennas) || antennas[0],
        );
      });
      setDetectedObjects(objects);
      // if (data.data) {
      //   setDetectedObjects(data.data);
      // }
    } catch (error) {
      console.error("Error fetching detected objects:", error);
    }
  };

  useEffect(() => {
    fetchDataFromAPI();
    const fetchAntennaData = async () => {
      // const res = generateAntenna(9.0579, 7.4951, 3, 5, 90);
      // setAntennas(res);
      const response = await fetch("/api/antenna");
      if (!response.ok) {
        setIsLoading(false);
        throw new Error("Failed to fetch antenna data");
      }
      const data = await response.json();
      setAntennas(data.data.data);
      setIsLoading(false);
    };
    fetchAntennaData();
    fetchStatsFromAPI();
  }, []); // Run once on mount

  // const generateSimulatedData = (): void => {
  //   if (antennas.length === 0) return;
  //   // Generate VHF signals

  //   if (Math.random() > 0.6) {
  //     // Independent random for each type
  //     const randomAntenna =
  //       antennas[Math.floor(Math.random() * antennas.length)];
  //     const newSignal = generateSignal(30, 300, "VHF", randomAntenna);
  //     if (newSignal) {
  //       setVhfSignals((prev) => [...prev, newSignal].slice(-8));
  //       setDetectedObjects((prev) => [...prev, newSignal].slice(-20));
  //       setMetricLength((prev) => ({
  //         ...prev,
  //         vhfLength: prev.vhfLength + 1,
  //       }));
  //     }
  //   }

  //   // Generate UHF signals
  //   if (Math.random() > 0.6) {
  //     // Independent random
  //     const randomAntenna =
  //       antennas[Math.floor(Math.random() * antennas.length)];
  //     const newSignal = generateSignal(300, 3000, "UHF", randomAntenna);
  //     if (newSignal) {
  //       setUhfSignals((prev) => [...prev, newSignal].slice(-8));
  //       setDetectedObjects((prev) => [...prev, newSignal].slice(-20));
  //       setMetricLength((prev) => ({
  //         ...prev,
  //         uhfLength: prev.uhfLength + 1,
  //       }));
  //     }
  //   }

  //   // Generate GSM signals
  //   if (Math.random() > 0.7) {
  //     // Independent random
  //     const randomAntenna =
  //       antennas[Math.floor(Math.random() * antennas.length)];
  //     const newSignal = generateSignal(900, 1800, "GSM", randomAntenna);
  //     if (newSignal) {
  //       setGsmSignals((prev) => [...prev, newSignal].slice(-8));
  //       setDetectedObjects((prev) => [...prev, newSignal].slice(-20));
  //       setMetricLength((prev) => ({
  //         ...prev,
  //         gsmLength: prev.gsmLength + 1,
  //       }));
  //     }
  //   }

  //   // Generate UAV signals (rare)
  //   // if (Math.random() > 0.85) {
  //   //   // Independent random
  //   //   const randomAntenna =
  //   //     antennas[Math.floor(Math.random() * antennas.length)];
  //   //   const newSignal = generateSignal(2400, 2500, "UAV", randomAntenna);
  //   //   if (newSignal) {
  //   //     setUavSignals((prev) => [...prev, newSignal].slice(-8));
  //   //     setDetectedObjects((prev) => [...prev, newSignal].slice(-20));
  //   //   }
  //   // }
  // };
  useEffect(() => {
    const interval = setInterval(() => {
      setTime(new Date());
      // generateSimulatedData();
      fetchDetectedObjectsFromAPI();
      setWaterfallVHF((prev) =>
        [generateWaterfallLine(), ...prev].slice(0, 30),
      );
      setWaterfallUHF((prev) =>
        [generateWaterfallLine(), ...prev].slice(0, 40),
      );
      setWaterfallGSM((prev) =>
        [generateWaterfallLine(), ...prev].slice(0, 50),
      );
      // setWaterfallUAV((prev) =>
      //   [generateWaterfallLine(), ...prev].slice(0, 60)
      // );
      // const random = Math.random();
      // if (random > 0.95) {
      //   const newAlert: Alert = {
      //     id: Date.now(),
      //     message: `High power signal detected at ${(random * 2970 + 30).toFixed(1)} MHz`,
      //     severity: random > 0.5 ? "high" : "medium",
      //     time: new Date().toLocaleTimeString(),
      //   };
      //   setAlerts((prev) => [newAlert, ...prev].slice(0, 10));
      // }
    }, 30000);

    return () => clearInterval(interval);
  }, [antennas]);

  const mapCenter: [number, number] = useMemo(() => {
    if (antennas.length === 0) return [9.8965, 8.8583];
    const avgLat =
      antennas.reduce((sum, a) => sum + a.lat, 0) / antennas.length;
    const avgLng =
      antennas.reduce((sum, a) => sum + a.lng, 0) / antennas.length;
    return [avgLat, avgLng];
  }, [antennas]);

  const handleRefresh = () => {
    window.location.reload();
  };

  const signalList = generateSignalList(vhfSignals, uhfSignals, gsmSignals);

  // const metricList = generateMetricList(
  //   metricLength.vhfLength,
  //   metricLength.uhfLength,
  //   metricLength.gsmLength,
  //   alerts.length
  // );

  const metricList = [
    {
      label: "Detected Objects",
      value: stats ? stats.summary.total_detections : 0,
      icon: Activity,
      color: "cyan",
      trend: true,
    },
    {
      label: "VHF Signals",
      value: stats
        ? getCountByLabel(stats.frequency_distribution, "walkie_vhf")
        : 0,
      icon: Radio,
      color: "green",
    },
    {
      label: "UHF Signals",
      value: stats
        ? getCountByLabel(stats.frequency_distribution, "walkie_uhf")
        : 0,
      icon: Radio,
      color: "purple",
    },
    {
      label: "GSM Signals",
      value: stats
        ? getCountByLabel(stats.frequency_distribution, "gsm_nigeria_900")
        : 0,
      icon: Radio,
      color: "cyan",
    },
    {
      label: "Alerts",
      value: alerts.length,
      icon: AlertTriangle,
      color: "red",
    },
  ];
  const waterfallList = generateWaterfallList(
    waterfallVHF,
    waterfallUHF,
    waterfallGSM,
    time,
  );

  return (
    <div
      className={` relative bg-gray-950 text-white ${isSidebarOpen ? "" : !mapMode ? "ml-10" : " "} w-full`}
    >
      <button
        className={`${!isSidebarOpen && "ml-10"} rounded-3xl px-4 py-2 bg-defaultCyan`}
        onClick={() => setMapMode((prev) => !prev)}
      >
        {mapMode ? (
          <div className="flex items-center  gap-1">
            Metric Mode
            <SiBaremetrics />{" "}
          </div>
        ) : (
          <div className="flex items-center gap-1">
            Map Mode
            <MdZoomOutMap />{" "}
          </div>
        )}
      </button>

      {mapMode ? (
        <div className="h-[650px] mt-3">
          <SignalMap
            detectedObjects={detectedObjects}
            selectedObject={selectedObject}
            onSelectObject={setSelectedObject}
            antennas={antennas}
            selectedAntenna={selectedAntenna}
            onSelectAntenna={setSelectedAntenna}
            mapCenter={mapCenter}
            largeView={largeView}
            setLargeView={setLargeView}
            isSidebarOpen={isSidebarOpen}
          />
        </div>
      ) : (
        <div>
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-3xl text-center font-bold mb-2 bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              Overwatch Antennas
            </h1>
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-4 text-sm text-gray-400">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span>System Active</span>
                  </div>
                  {/* <span>{time.toLocaleString()}</span> */}
                </div>
              </div>
              <button
                onClick={handleRefresh}
                disabled={isLoading}
                className="flex items-center gap-2 bg-cyan-600 hover:bg-cyan-700 disabled:bg-gray-700 px-4 py-2 rounded-lg text-sm font-semibold transition-colors"
              >
                <RefreshCw
                  size={16}
                  className={isLoading ? "animate-spin" : ""}
                />
                {isLoading ? "Syncing..." : "Sync API"}
              </button>
            </div>
          </div>

          {/* Metrics Row */}
          <div className="grid grid-cols-5 gap-3 mb-6">
            {metricList.map(({ label, value, icon, color, trend }) => (
              <MetricCard
                key={label}
                icon={icon}
                label={label}
                value={value}
                color={color}
                trend={trend}
              />
            ))}
          </div>

          {/* Map and Object Details */}
          <div
            className={`grid ${largeView ? "grid-cols-1" : "grid-cols-2"}  gap-4 mb-6`}
          >
            <div className="bg-gray-900 p-4 rounded-lg border border-cyan-500/30">
              <div className="flex justify-between">
                <h3 className="text-cyan-400 text-sm font-semibold mb-2 flex items-center gap-2">
                  <MapPin size={16} />
                  Real-Time Geolocation Map
                </h3>
                <button
                  onClick={() => setLargeView((prev) => !prev)}
                  className="text-defaultBlue hover:text-white text-xs"
                >
                  {largeView ? <BsFullscreenExit /> : <BsArrowsFullscreen />}
                </button>
              </div>
              <div
                className={`${largeView ? "h-[500px]" : "h-[450px]"}  border-[8px] border-cyan-500/30 rounded-lg`}
              >
                <SignalMap
                  detectedObjects={detectedObjects}
                  selectedObject={selectedObject}
                  onSelectObject={setSelectedObject}
                  antennas={antennas}
                  selectedAntenna={selectedAntenna}
                  onSelectAntenna={setSelectedAntenna}
                  mapCenter={mapCenter}
                  largeView={largeView}
                  setLargeView={setLargeView}
                  isSidebarOpen={isSidebarOpen}
                />
              </div>
              <div className="mt-2 text-xs text-gray-400 flex items-center justify-between">
                <span>Click markers for details</span>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span>VHF</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                    <span>UHF</span>
                  </div>

                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <span>GSM</span>
                  </div>

                  {/* <div className="flex items-center gap-1">
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <span>UAV</span>
              </div> */}
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-red-600 rounded-full border-2 border-white"></div>
                    <span>ANT</span>
                  </div>
                </div>
              </div>
            </div>
            <ObjectDetails
              hide={largeView}
              selectedObject={selectedObject}
              setSelectedObject={setSelectedObject}
            />
          </div>

          {/* Waterfall Displays */}
          {/* <div className="grid grid-cols-3 gap-2 mb-6">
            {waterfallList.map(({ data, title, freqRange, time }) => (
              <WaterfallDisplay
                key={title}
                data={data}
                title={title}
                freqRange={freqRange}
                time={time.toLocaleTimeString()}
              />
            ))}
          </div> */}

          {/* Signal Lists and Alerts */}
          <div className="grid grid-cols-4 gap-2">
            {signalList.map(({ signal, title, color }) => (
              <SignalList
                key={title}
                signals={signal}
                title={title}
                setLargeView={setLargeView}
                setSelectedObject={setSelectedObject}
                color={color}
              />
            ))}

            {/* Alerts Panel */}
            <AlertPanel alerts={alerts} />
          </div>
        </div>
      )}
    </div>
  );
};

export default UHFVHFDashboard;
