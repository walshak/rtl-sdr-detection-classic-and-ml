/* eslint-disable @typescript-eslint/no-explicit-any */
export interface PaginationResponse<T> {
  data: T[];
  page: number;
  limit: number;
  totalCount: number;
  totalPages: number;
}
type Filter = Record<string, any>;

export interface PaginateQueryParams {
  page?: number;
  limit?: number;
  search?: string;
  filter?: Filter;
  sortBy?: string;
  sortOrder?: "asc" | "desc";
}
export class PaginateService {
  private applyFilterAndSearch = (search: string, filter: Filter) => {
    let where: Record<string, any> = {};

    if (search) {
      where = {
        ...where,
        OR: [
          { name: { contains: search, mode: "insensitive" } },
          { description: { contains: search, mode: "insensitive" } },
        ],
      };
    }

    if (filter) {
      where = { ...where, ...filter };
    }

    return where;
  };

  private formatResponse = <T>(
    results: T[],
    total: number,
    page: number,
    limit: number,
  ): PaginationResponse<T> => {
    const totalPages = Math.ceil(total / limit);
    return {
      data: results,
      page,
      limit,
      totalCount: total,
      totalPages,
    };
  };

  private transformQueryParams(queryParams: Record<string, any>) {
    const transformedParams = {
      filter: (() => {
        try {
          return queryParams.filter ? JSON.parse(queryParams.filter) : {};
        } catch (error) {
          console.error("Invalid JSON in filter:", error);
          return {};
        }
      })(),
      sortBy: queryParams.sortBy || "createdAt",
      search: queryParams.search ? queryParams.search.toString() : "",
      page: Number.isNaN(+queryParams.page) ? 1 : +queryParams.page,
      limit: Number.isNaN(+queryParams.limit) ? 10 : +queryParams.limit,
      sortOrder:
        typeof queryParams.sortOrder === "string"
          ? queryParams.sortOrder.toLowerCase()
          : "desc",
    };
    return transformedParams;
  }

  async paginate(
    model: any,
    queryParams: PaginateQueryParams,
    select?: Record<string, boolean>,
    include?: Record<string, boolean>,
  ) {
    try {
      const { page, limit, search, filter, sortBy, sortOrder } =
        this.transformQueryParams(queryParams);

      const skip = (page - 1) * limit;
      const take = +limit;

      const where = this.applyFilterAndSearch(search || "", filter || {});
      const countQuery = model.count({ where });
      const dataQuery = model.findMany({
        where,
        skip,
        take,
        select,
        orderBy: { [sortBy]: sortOrder },
        include,
      });

      const totalCount = await countQuery;
      const data: any[] = await dataQuery;

      return this.formatResponse(data, totalCount, page, limit);
    } catch (error) {
      console.log(error);
    }
  }
}
