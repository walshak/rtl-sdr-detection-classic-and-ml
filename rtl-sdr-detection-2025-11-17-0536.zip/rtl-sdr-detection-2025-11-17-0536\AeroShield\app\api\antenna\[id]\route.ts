import { NextRequest, NextResponse } from "next/server";
import { AntennaService } from "../antenna.service";
import { RouteContext } from "@/types/api";
import { validateDto } from "@/util/validateDto";
import { updateAntennaSchema } from "@/lib/joiSchema";

const antennaService = new AntennaService();
export async function GET(_: NextRequest, { params }: RouteContext) {
  try {
    const id = (await params).id;
    const antenna = await antennaService.findById(id);
    return NextResponse.json(
      {
        message: `Antenna with id:${id} retrieved`,
        data: antenna,
        success: true,
      },
      { status: 200 },
    );
  } catch (error) {
    return NextResponse.json(
      {
        message: "An error occured while fetching antenna by id",
        success: false,
        error: (error as Error).message,
      },
      { status: 500 },
    );
  }
}

export async function PUT(req: NextRequest, { params }: RouteContext) {
  try {
    const id = (await params).id;
    const body = await req.json();
    const validateError = await validateDto(updateAntennaSchema)(body);
    if (validateError) return validateError;
    const antenna = await antennaService.update(id, body);
    return NextResponse.json(
      {
        message: `Antenna with id: ${id} updated`,
        data: antenna,
        success: true,
      },
      { status: 200 },
    );
  } catch (error) {
    return NextResponse.json(
      {
        message: "An error occured while updating antenna",
        success: false,
        error: (error as Error).message,
      },
      { status: 500 },
    );
  }
}

export async function DELETE(_: NextRequest, { params }: RouteContext) {
  try {
    const id = (await params).id;
    await antennaService.delete(id);
    return NextResponse.json(
      {
        message: `Antenna with id: ${id} deleted`,
        success: true,
      },
      { status: 200 },
    );
  } catch (error) {
    return NextResponse.json(
      {
        message: "An error occured while deleting antenna",
        success: false,
        error: (error as Error).message,
      },
      { status: 500 },
    );
  }
}
