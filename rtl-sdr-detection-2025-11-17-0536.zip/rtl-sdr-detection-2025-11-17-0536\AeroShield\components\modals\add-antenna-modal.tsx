import { AntennaData } from "@/types/signal";
import { useState } from "react";
import { toast } from "react-toastify";
import { Spinner } from "../common/Spinner";

interface AddAntennaModalProps {
  modalOpen: boolean;
  setModalOpen: (value: boolean) => void;
  newAntenna: (antenna: AntennaData) => void;
  antennasLength: number;
}
interface FormData {
  name: string;
  lat: string;
  lng: string;
  coverage_radius: string;
  direction: string;
  coverage_angle: string;
  status: "active" | "inactive" | "maintenance";
  size: string;
}
export default function AddAntennaModal({
  modalOpen,
  setModalOpen,
  newAntenna,
  antennasLength,
}: AddAntennaModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    lat: "",
    lng: "",
    coverage_radius: "",
    direction: "",
    coverage_angle: "",
    size: "",
    status: "active" as "active" | "inactive" | "maintenance",
  });

  const [isLoading, setIsLoading] = useState(false);

  const handleBackgroundClick = (
    e: React.MouseEvent<HTMLDivElement, MouseEvent>,
  ) => {
    if (e.target === e.currentTarget) {
      setModalOpen(false);
    }
  };

  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >,
  ) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleCreateAntenna = async () => {
    setIsLoading(true);
    const { lat, lng, name, coverage_angle, coverage_radius, size } = formData;
    if (!name || !lat || !lng || !coverage_angle || !coverage_radius || !size) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      // await new Promise((resolve) => setTimeout(resolve, 1000));
      const createDto = {
        name: formData.name,
        lat: parseFloat(lat),
        lng: parseFloat(lng),
        coverage_radius: parseFloat(coverage_radius),
        direction: parseFloat(formData.direction),
        coverage_angle: parseFloat(coverage_angle),
        status: formData.status,
        size: parseFloat(formData.size),
      };
      const response = await fetch("/api/antenna", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(createDto),
      });
      if (!response.ok) {
        throw new Error("Failed to create antenna");
      }
      const data = await response.json();
      const antenna: AntennaData = data.data;
      newAntenna(antenna);
      toast.success("Antenna created successfully");
    } catch (error) {
      // Now shows only one error toast with the appropriate message
      toast.error(
        error instanceof Error ? error.message : "Failed to create antenna",
      );
    } finally {
      setIsLoading(false);
      setModalOpen(false);
    }
  };

  return (
    modalOpen && (
      <div
        onClick={handleBackgroundClick}
        aria-label="Add Antenna Modal"
        className="w-screen h-screen text-white flex justify-center items-center fixed top-0 left-0 z-30 bg-black/50 backdrop-blur-sm"
      >
        <div className="md:w-[50%]  rounded-[24px] flex flex-col p-8 bg-white/10">
          <h2 className="text-2xl font-bold">Add New Antenna</h2>
          <div className="w-full grid grid-cols-2 gap-3 mt-2 overflow-y-auto">
            <CustomInput
              formData={formData}
              handleInputChange={handleInputChange}
              label="Antenna Name"
              name="name"
              placeholder="Antenna 1"
            />
            <CustomInput
              formData={formData}
              handleInputChange={handleInputChange}
              label="Latitude"
              name="lat"
              placeholder="9.6748"
            />
            <CustomInput
              formData={formData}
              handleInputChange={handleInputChange}
              label="Longitude"
              name="lng"
              placeholder="7.4856"
            />
            <CustomInput
              formData={formData}
              handleInputChange={handleInputChange}
              label="Coverage Radius (km):"
              name="coverage_radius"
              placeholder="3"
            />
            <CustomInput
              formData={formData}
              handleInputChange={handleInputChange}
              label="Direction (°)"
              name="direction"
              placeholder="90"
            />
            <CustomInput
              formData={formData}
              handleInputChange={handleInputChange}
              label="Coverage Angle (°)"
              name="coverage_angle"
              placeholder="120"
            />
            <CustomInput
              formData={formData}
              handleInputChange={handleInputChange}
              label="Size (m)"
              name="size"
              placeholder="40"
            />

            <div className="w-full flex flex-col gap-2">
              <label htmlFor="productType" className="text-sm">
                Select Status
              </label>
              <select
                id="status"
                onChange={handleInputChange}
                name="status"
                value={formData.status}
                className="p-3 outline-none w-full rounded-lg text-black placeholder:text-black/50 bg-white/70 "
              >
                <option disabled value="">
                  Select
                </option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="maintenance">Maintenance</option>
              </select>
            </div>
          </div>
          <div className="mt-5 flex items-center justify-end gap-x-3 text-sm">
            <button
              onClick={() => setModalOpen(false)}
              className="rounded-lg hover:underline"
            >
              Cancel
            </button>
            <button
              onClick={handleCreateAntenna}
              className="px-5 py-3 rounded-lg text-white bg-cyan-600 hover:bg-cyan-700"
            >
              {isLoading ? <Spinner /> : "Create Antenna"}
            </button>
          </div>
        </div>
      </div>
    )
  );
}

const CustomInput = ({
  formData,
  handleInputChange,
  label,
  name,
  placeholder,
}: {
  formData: Record<string, string>;
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  label: string;
  name: keyof FormData;
  placeholder: string;
}) => {
  return (
    <div className="flex flex-col gap-y-2 text-sm">
      <label htmlFor={name} className="">
        {label}
      </label>
      <input
        type="text"
        name={name}
        id={name}
        value={formData[name]}
        onChange={handleInputChange}
        className="w-full p-3 rounded-lg text-black placeholder:text-black/50 bg-white/70  outline-none focus:ring-2 focus:outline-none focus:ring-defaultCyan focus:border-transparent"
        placeholder={`e.g ${placeholder}`}
      />
    </div>
  );
};
