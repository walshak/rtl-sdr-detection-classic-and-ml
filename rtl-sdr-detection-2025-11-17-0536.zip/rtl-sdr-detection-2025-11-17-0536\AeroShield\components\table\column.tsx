import { GridColDef } from "@mui/x-data-grid";

export const AntennaColumns: GridColDef[] = [
  { field: "name", headerName: "Antenna name", flex: 1 },
  { field: "id", headerName: "ID", flex: 0.2, sortable: false },

  { field: "lat", headerName: "Latitude", flex: 1, sortable: false },
  { field: "lng", headerName: "Longitude", flex: 1, sortable: false },
  { field: "size", headerName: "Size (m)", flex: 1, sortable: false },
  {
    field: "coverage_radius",
    headerName: "Coverage Radius (km)",
    flex: 1,
    sortable: false,
  },
  {
    field: "coverage_angle",
    headerName: "Coverage Angle (°)",
    flex: 1,
    sortable: false,
  },

  { field: "direction", headerName: "Direction (°)", flex: 1, sortable: false },
];

export const ActivitiesColumns: GridColDef[] = [
  { field: "timestamp", headerName: "Time", flex: 1 },
  { field: "freq", headerName: "Freq (MHz)", flex: 1, sortable: false },
  { field: "type", headerName: "Type", flex: 1, sortable: false },
  { field: "snr", headerName: "SNR (dB)", flex: 1, sortable: false },
  { field: "peak_power", headerName: "Peak (dB)", flex: 1, sortable: false },
  {
    field: "quality",
    headerName: "Quality (%)",
    renderCell: ({ row }) => (
      <span
        style={{
          color: row.quality_color,
        }}
      >
        {row.quality}%
      </span>
    ),
    flex: 1,
    sortable: false,
  },
];
