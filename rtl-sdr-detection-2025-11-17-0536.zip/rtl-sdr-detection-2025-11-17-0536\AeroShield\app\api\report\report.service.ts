import { prisma } from "@/lib/prisma";
import { PaginateQueryParams, PaginateService } from "@/util/paginate";
import { Prisma } from "@prisma/client";

export class ReportService {
  private paginateService = new PaginateService();

  async create(data: Prisma.ReportCreateInput) {
    try {
      return await prisma.report.create({ data });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError) {
        // Unique constraint violation (code 'P2002')
        if (error.code === "P2002") {
          throw new Error(
            `A PaidRequest with this ${error.meta?.target} already exists.`,
          );
        }
      }
      throw error; // Re-throw other errors
    }
  }

  async getAllReports(query?: PaginateQueryParams) {
    const reportModel = prisma.report;
    if (query) {
      return await this.paginateService.paginate(reportModel, query);
    }
    return prisma.report.findMany();
  }

  async findById(id: string) {
    return await prisma.report.findUnique({ where: { id } });
  }

  async update(id: string, data: Prisma.ReportUpdateInput) {
    return await prisma.report.update({ where: { id }, data });
  }

  async delete(id: string) {
    return await prisma.report.delete({ where: { id } });
  }
}
