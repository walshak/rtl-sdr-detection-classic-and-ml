"use client";
import { useSidebar } from "@/hooks/SidebarContex";
import { FcGlobe } from "react-icons/fc";
import { GiPathDistance } from "react-icons/gi";
import { Card } from "./Card";
import { useEffect, useState } from "react";
import { formatTimestamp, safeFixed, safeFreq } from "@/util/helper";
import { IoPersonOutline } from "react-icons/io5";
import { BsFillQuestionDiamondFill } from "react-icons/bs";
import Cookies from "js-cookie";
import MuiTableComponent from "../table/tableComp";
import { ActivitiesColumns } from "../table/column";

export default function Dashboard() {
  const { isSidebarOpen } = useSidebar();
  const [loading, setLoading] = useState<boolean>(true);
  const [user, setUser] = useState<User | null>(null);
  const [metric, setMetric] = useState<{ antenna_name: number } | null>(null);

  const [detection, setDetection] = useState<RecentActivities[]>([]);

  const cardData = [
    {
      title: "Active Antennas",
      content: String(metric?.antenna_name ?? 0),
      // icon: <div className="text-4xl">📡</div>,
      icon: <BsFillQuestionDiamondFill size={40} />,
    },
    {
      title: "Coverage Area",
      content: "687.5km",
      icon: (
        <div>
          <FcGlobe size={40} />
        </div>
      ),
    },
    {
      title: "Avg Range",
      content: "4600m",
      icon: (
        <div>
          <GiPathDistance size={40} />
        </div>
      ),
    },
  ];

  const fetchAntennaLength = async () => {
    const response = await fetch("/api/antenna");
    if (!response.ok) {
      setLoading(false);
      throw new Error("Failed to fetch antenna data");
    }
    const data = await response.json();
    setMetric((prev) => ({ ...prev, antenna_name: data.data.data.length }));
    setLoading(false);
  };

  useEffect(() => {
    const userData = Cookies.get("user");
    if (userData) {
      setUser(JSON.parse(userData));
    }

    const fetchDetections = async () => {
      try {
        const response = await fetch(`/api/external/detections`);
        const data = await response.json();
        const detections = data.data.results;
        /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
        const objects = detections.map((item: any) => {
          const rawQuality =
            item.signal_quality_index ??
            (item.snr ? Math.min(100, Math.max(0, item.snr * 2)) : 0);
          const quality = Number(safeFixed(rawQuality, 0));
          const qualityColor =
            quality > 70
              ? "text-green-600"
              : quality > 40
                ? "text-yellow-600"
                : "text-red-600";
          return {
            //  confidence: safeFixed(item.confidence_score, 0),
            id: item.id,
            quality,
            freq: safeFreq(item.freq),
            type: item.label,
            peak_power: safeFixed(item.peak_power, 1),
            // duration: item.duration,
            snr: safeFixed(item.snr, 1),
            timestamp: formatTimestamp(item.timestamp),
            quality_color: qualityColor,
          };
        });
        setDetection(objects);
      } catch (error) {
        throw new Error("Failed to fetch recent detections");
      } finally {
        setLoading(false);
      }
    };
    fetchAntennaLength();
    fetchDetections();
  }, []);
  return (
    <div
      className={`flex flex-col text-white  ${isSidebarOpen ? "ml-2" : ""} px-4 py-2`}
    >
      <div className="flex justify-between w-full gap-20 items-center">
        <h1 className="font-bold gradient-text text-4xl">Dashboard</h1>
        <p className="text-white flex gap-2 items-center rounded-3xl px-4 py-2 bg-defaultCyan">
          <IoPersonOutline /> {user?.role === "ADMIN" ? "Admin" : "Operator"}
        </p>
      </div>

      <section className="mt-4 bg-gray-900 p-4 flex flex-col gap-6 justify-center rounded-3xl  border border-cyan-500/30 shadow-lg">
        <h2 className="text-3xl font-bold gradient-text ">
          Welcome back, {user?.name}!{" "}
        </h2>
        <p>
          Monitor and manage your AeroShield antenna network coverage
          system.{" "}
        </p>
      </section>
      <section className={`mt-4  grid grid-cols-3 gap-8`}>
        {cardData.map((card, index) => (
          <Card
            key={index}
            title={card.title}
            content={card.content}
            icon={card.icon}
          />
        ))}
      </section>

      <section className="mt-4 bg-gray-900 p-4 flex flex-col justify-center rounded-3xl border border-cyan-500/30 shadow-lg">
        <h3 className="gradient-text font-semibold text-2xl">
          Recent Detections
        </h3>
        <div>
          {loading ? (
            <p className="text-gray-400 mt-4">Loading activities...</p>
          ) : detection.length === 0 ? (
            <p className="text-gray-400 mt-4">No recent activities.</p>
          ) : (
            // <ul className="mt-4 space-y-2">
            //   {activities.map((activity) => (
            //     <li
            //       key={activity.id}
            //       className="border-b border-gray-700 flex justify-between pb-2"
            //     >
            //       <div className="flex gap-3 items-center">
            //         <span className="size-2 rounded-full bg-green-600"></span>
            //         <div className="">📡</div>
            //         <p>
            //           <span className="font-semibold">
            //             {activity.description}
            //           </span>{" "}
            //           {/* - {activity.activity_type} */}
            //         </p>
            //       </div>

            //       <p className="text-sm text-gray-500">
            //         {new Date(activity.timestamp).toLocaleString()}
            //       </p>
            //     </li>
            //   ))}
            // </ul>
            // <section
            //   className={`mt-4 bg-gray-900 p-4 ${isSidebarOpen ? "w-[1000px]" : ""} rounded-lg border border-cyan-500/30 shadow-lg`}
            // >
            <section
              className={`mt-4 p-4 ${isSidebarOpen ? "w-[1120px]" : "full"} `}
            >
              <MuiTableComponent
                columns={ActivitiesColumns}
                loading={loading}
                rows={detection}
                pageSize={10}
              />
            </section>
          )}
        </div>
      </section>
    </div>
  );
}
