// middleware/auth.ts
import { verifyToken } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";

export function authMiddleware(req: NextRequest) {
  const authHeader = req.headers.get("authorization");

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return NextResponse.json(
      { error: "Unauthorized - No token provided" },
      { status: 401 },
    );
  }

  const token = authHeader.substring(7);
  const payload = verifyToken(token);

  if (!payload) {
    return NextResponse.json(
      { error: "Unauthorized - Invalid token" },
      { status: 401 },
    );
  }

  // Attach user info to request headers for downstream use
  const requestHeaders = new Headers(req.headers);
  requestHeaders.set("x-user-id", payload.userId);
  requestHeaders.set("x-user-email", payload.email);

  return NextResponse.next({
    request: {
      headers: requestHeaders,
    },
  });
}

// Helper function to get user from request headers
export function getUserFromRequest(req: NextRequest) {
  return {
    userId: req.headers.get("x-user-id"),
    email: req.headers.get("x-user-email"),
  };
}
