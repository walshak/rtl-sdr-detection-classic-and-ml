// components/map/MultiAntennaMap.tsx
import React from "react";
import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  Polyline,
  Polygon,
  Circle,
} from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

interface AntennaData {
  id: number;
  name: string;
  lat: number;
  lng: number;
  coverageRadius: number;
  direction: number;
  coverageAngle: number;
  type: "VHF" | "UHF" | "BOTH";
  status: "active" | "inactive" | "maintenance";
}

interface SignalData {
  id: number;
  frequency: number;
  type: "VHF" | "UHF";
  lat: number;
  lng: number;
  bearing: number;
  distance: number;
  strength: string;
  snr: string;
  modulation: string;
  bandwidth: string;
  detectedByAntennaId?: number;
}

interface MultiAntennaMapProps {
  detectedObjects: SignalData[];
  selectedObject: SignalData | null;
  onSelectObject: (obj: SignalData) => void;
  antennas: AntennaData[];
  selectedAntenna: AntennaData | null;
  onSelectAntenna: (antenna: AntennaData) => void;
}

const MultiAntennaMap: React.FC<MultiAntennaMapProps> = ({
  detectedObjects,
  selectedObject,
  onSelectObject,
  antennas,
  selectedAntenna,
  onSelectAntenna,
}) => {
  // Calculate sector polygon for directional coverage
  const calculateSectorPolygon = (
    lat: number,
    lng: number,
    radius: number,
    direction: number,
    angle: number
  ): [number, number][] => {
    const points: [number, number][] = [];
    const startAngle = direction - angle / 2;
    const endAngle = direction + angle / 2;
    const segments = 40;

    points.push([lat, lng]);

    for (let i = 0; i <= segments; i++) {
      const currentAngle =
        startAngle + (endAngle - startAngle) * (i / segments);
      const rad = (currentAngle * Math.PI) / 180;

      const R = 6371;
      const lat1 = (lat * Math.PI) / 180;
      const lng1 = (lng * Math.PI) / 180;

      const lat2 = Math.asin(
        Math.sin(lat1) * Math.cos(radius / R) +
          Math.cos(lat1) * Math.sin(radius / R) * Math.cos(rad)
      );

      const lng2 =
        lng1 +
        Math.atan2(
          Math.sin(rad) * Math.sin(radius / R) * Math.cos(lat1),
          Math.cos(radius / R) - Math.sin(lat1) * Math.sin(lat2)
        );

      points.push([(lat2 * 180) / Math.PI, (lng2 * 180) / Math.PI]);
    }

    points.push([lat, lng]);
    return points;
  };

  // Antenna colors based on type
  const getAntennaColor = (type: "VHF" | "UHF" | "BOTH") => {
    switch (type) {
      case "VHF":
        return "#22c55e"; // green
      case "UHF":
        return "#a855f7"; // purple
      case "BOTH":
        return "#06b6d4"; // cyan
    }
  };

  // Create antenna icon
  const createAntennaIcon = (antenna: AntennaData, isSelected: boolean) => {
    const color = getAntennaColor(antenna.type);
    const statusColor =
      antenna.status === "active"
        ? color
        : antenna.status === "maintenance"
          ? "#eab308"
          : "#ef4444";
    const size = isSelected ? 28 : 20;

    return L.divIcon({
      className: "antenna-marker",
      html: `
        <div style="position: relative; width: ${size}px; height: ${size}px;">
          <!-- Antenna tower icon -->
          <svg width="${size}" height="${size}" viewBox="0 0 24 24" style="filter: drop-shadow(0 0 ${isSelected ? "10px" : "6px"} ${statusColor});">
            <path d="M12 2L4 22h16L12 2z" fill="${statusColor}" stroke="white" stroke-width="1.5"/>
            <circle cx="12" cy="16" r="2" fill="white"/>
          </svg>
          ${
            isSelected
              ? `
            <div style="
              position: absolute;
              top: 50%;
              left: 50%;
              transform: translate(-50%, -50%);
              width: ${size * 1.8}px;
              height: ${size * 1.8}px;
              border: 2px solid ${statusColor};
              border-radius: 50%;
              animation: pulse-antenna 1.5s infinite;
            "></div>
          `
              : ""
          }
          <!-- Antenna label -->
          <div style="
            position: absolute;
            top: ${size + 2}px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0,0,0,0.8);
            color: white;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: bold;
            white-space: nowrap;
          ">${antenna.name}</div>
        </div>
      `,
      iconSize: [size, size + 20],
      iconAnchor: [size / 2, size],
    });
  };

  // Create signal icon
  const createSignalIcon = (type: "VHF" | "UHF", isSelected: boolean) => {
    const color = type === "VHF" ? "#22c55e" : "#a855f7";
    const size = isSelected ? 14 : 10;

    return L.divIcon({
      className: "signal-marker",
      html: `
        <div style="
          background: ${color};
          width: ${size}px;
          height: ${size}px;
          border-radius: 50%;
          border: 2px solid white;
          box-shadow: 0 0 ${isSelected ? "15px" : "10px"} ${color};
        "></div>
      `,
      iconSize: [size, size],
      iconAnchor: [size / 2, size / 2],
    });
  };

  // Add animations
  React.useEffect(() => {
    if (!document.getElementById("antenna-animations")) {
      const style = document.createElement("style");
      style.id = "antenna-animations";
      style.innerHTML = `
        @keyframes pulse-antenna {
          0% {
            opacity: 1;
            transform: translate(-50%, -50%) scale(1);
          }
          100% {
            opacity: 0;
            transform: translate(-50%, -50%) scale(2);
          }
        }
      `;
      document.head.appendChild(style);
    }
  }, []);

  // Calculate map center (average of all antenna positions)
  const mapCenter: [number, number] = React.useMemo(() => {
    if (antennas.length === 0) return [40.7128, -74.006];
    const avgLat =
      antennas.reduce((sum, a) => sum + a.lat, 0) / antennas.length;
    const avgLng =
      antennas.reduce((sum, a) => sum + a.lng, 0) / antennas.length;
    return [avgLat, avgLng];
  }, [antennas]);

  return (
    <MapContainer
      center={mapCenter}
      zoom={13}
      scrollWheelZoom={true}
      style={{ height: "100%", width: "100%", borderRadius: "8px" }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />

      {/* Render All Antennas with Coverage */}
      {antennas.map((antenna) => {
        const isSelected = selectedAntenna?.id === antenna.id;
        const color = getAntennaColor(antenna.type);

        // Calculate coverage sector
        const sectorPoints = calculateSectorPolygon(
          antenna.lat,
          antenna.lng,
          antenna.coverageRadius,
          antenna.direction,
          antenna.coverageAngle
        );

        const opacity = antenna.status === "active" ? 0.2 : 0.08;
        const strokeOpacity = isSelected
          ? 0.9
          : antenna.status === "active"
            ? 0.5
            : 0.3;

        return (
          <React.Fragment key={antenna.id}>
            {/* Coverage Sector (Directional) */}
            <Polygon
              positions={sectorPoints}
              pathOptions={{
                color: color,
                fillColor: color,
                fillOpacity: opacity,
                weight: isSelected ? 3 : 2,
                opacity: strokeOpacity,
                dashArray:
                  antenna.status === "maintenance" ? "10, 5" : undefined,
              }}
              eventHandlers={{
                click: () => onSelectAntenna(antenna),
              }}
            />

            {/* Full Coverage Circle (lighter, for reference) */}
            <Circle
              center={[antenna.lat, antenna.lng]}
              radius={antenna.coverageRadius * 1000}
              pathOptions={{
                color: color,
                weight: 1,
                opacity: 0.15,
                fillOpacity: 0.05,
                dashArray: "5, 10",
              }}
            />

            {/* Direction indicator line (when selected) */}
            {isSelected && (
              <Polyline
                positions={[
                  [antenna.lat, antenna.lng],
                  sectorPoints[Math.floor(sectorPoints.length / 2)],
                ]}
                pathOptions={{
                  color: color,
                  weight: 3,
                  opacity: 0.9,
                  dashArray: "8, 4",
                }}
              />
            )}

            {/* Antenna Marker */}
            <Marker
              position={[antenna.lat, antenna.lng]}
              icon={createAntennaIcon(antenna, isSelected)}
              eventHandlers={{
                click: () => onSelectAntenna(antenna),
              }}
              zIndexOffset={1000}
            >
              <Popup>
                <div
                  style={{
                    fontFamily: "monospace",
                    fontSize: "11px",
                    minWidth: "180px",
                  }}
                >
                  <b style={{ fontSize: "13px", color: color }}>
                    {antenna.name}
                  </b>
                  <br />
                  <hr
                    style={{
                      margin: "4px 0",
                      border: "none",
                      borderTop: `1px solid ${color}`,
                    }}
                  />
                  <b>Type:</b> {antenna.type}
                  <br />
                  <b>Status:</b>{" "}
                  <span
                    style={{
                      color:
                        antenna.status === "active"
                          ? "#22c55e"
                          : antenna.status === "maintenance"
                            ? "#eab308"
                            : "#ef4444",
                    }}
                  >
                    {antenna.status.toUpperCase()}
                  </span>
                  <br />
                  <b>Direction:</b> {antenna.direction}°<br />
                  <b>Coverage Angle:</b> {antenna.coverageAngle}°<br />
                  <b>Radius:</b> {antenna.coverageRadius.toFixed(2)} km
                  <br />
                  <b>Location:</b>
                  <br />
                  &nbsp;&nbsp;{antenna.lat.toFixed(6)}, {antenna.lng.toFixed(6)}
                </div>
              </Popup>
            </Marker>
          </React.Fragment>
        );
      })}

      {/* Render Detected Signals */}
      {detectedObjects.map((obj) => {
        const isSelected = selectedObject?.id === obj.id;
        const color = obj.type === "VHF" ? "#22c55e" : "#a855f7";
        const detectingAntenna = antennas.find(
          (a) => a.id === obj.detectedByAntennaId
        );

        return (
          <React.Fragment key={obj.id}>
            {/* Line from detecting antenna to signal */}
            {detectingAntenna && (
              <Polyline
                positions={[
                  [detectingAntenna.lat, detectingAntenna.lng],
                  [obj.lat, obj.lng],
                ]}
                pathOptions={{
                  color: color,
                  weight: isSelected ? 2.5 : 1.5,
                  opacity: isSelected ? 0.7 : 0.4,
                  dashArray: "5, 10",
                }}
              />
            )}

            {/* Signal Marker */}
            <Marker
              position={[obj.lat, obj.lng]}
              icon={createSignalIcon(obj.type, isSelected)}
              eventHandlers={{
                click: () => onSelectObject(obj),
              }}
              zIndexOffset={500}
            >
              <Popup>
                <div
                  style={{
                    fontFamily: "monospace",
                    fontSize: "11px",
                    minWidth: "180px",
                  }}
                >
                  <b style={{ fontSize: "13px", color: color }}>
                    {obj.type} Signal
                  </b>
                  <br />
                  <hr
                    style={{
                      margin: "4px 0",
                      border: "none",
                      borderTop: `1px solid ${color}`,
                    }}
                  />
                  <b>Frequency:</b> {obj.frequency.toFixed(2)} MHz
                  <br />
                  <b>Strength:</b> {obj.strength} dBm
                  <br />
                  <b>SNR:</b> {obj.snr} dB
                  <br />
                  <b>Modulation:</b> {obj.modulation}
                  <br />
                  <b>Bandwidth:</b> {obj.bandwidth} kHz
                  <br />
                  <b>Bearing:</b> {obj.bearing}°<br />
                  <b>Distance:</b> {obj.distance.toFixed(2)} km
                  <br />
                  <b>Detected By:</b> {detectingAntenna?.name || "Unknown"}
                  <br />
                  <b>Location:</b>
                  <br />
                  &nbsp;&nbsp;{obj.lat.toFixed(6)}, {obj.lng.toFixed(6)}
                </div>
              </Popup>
            </Marker>
          </React.Fragment>
        );
      })}
    </MapContainer>
  );
};

export default MultiAntennaMap;
