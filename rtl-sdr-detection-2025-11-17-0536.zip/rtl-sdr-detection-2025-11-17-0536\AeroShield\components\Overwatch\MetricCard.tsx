import { LucideIcon, TrendingUp } from "lucide-react";

interface MetricCardProps {
  icon: LucideIcon;
  label: string;
  value: number;
  trend?: boolean;
  color: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  icon: Icon,
  label,
  value,
  trend,
  color,
}) => (
  <div className="bg-gray-900 p-4  rounded-lg border border-gray-700">
    <div className="flex items-center justify-between mb-2">
      <Icon className={`text-${color}-400`} size={20} />
      {trend && <TrendingUp className="text-green-400" size={16} />}
    </div>
    <div className={`text-2xl font-bold text-${color}-400 mb-1`}>{value}</div>
    <div className="text-xs text-gray-400">{label}</div>
  </div>
);
