// types/types.d.ts
import type { FieldError, UseFormRegister } from "react-hook-form";

declare global {
  // form data interface
  interface SignInFormData {
    email: string;
    password: string;
  }

  interface SignUpFormData {
    name: string;
    email: string;
    password: string;
    role?: "ADMIN" | "OPERATOR";
  }

  interface FormFieldProps {
    type: string;
    placeholder: string;
    name: ValidFieldNames;
    register:
      | UseFormRegister<SignInFormData | SignUpFormData>
      | UseFormRegister<SignUpFormData>;
    error: FieldError | undefined;
    valueAsNumber?: boolean;
  }

  interface SelectFieldProps {
    name: ValidFieldNames;
    register:
      | UseFormRegister<SignInFormData | SignUpFormData>
      | UseFormRegister<SignUpFormData>;
    error: FieldError | undefined;
    valueAsNumber?: boolean;
    options?: Array<{ label: string; value: string }>;
  }

  type ValidFieldNames = "email" | "password" | "name" | "role";

  interface User {
    id: number;
    name: string;
    email: string;
    role: "ADMIN" | "OPERATOR";
  }

  interface Stats {
    summary: StatsSummary;
    frequency_distribution: { count: number; label: string }[];
    hourly_activity: { count: number; hour: string }[];
  }

  interface StatsSummary {
    avg_quality: number;
    avg_snr: number;
    device_count: number;
    recent_24h: number;
    signal_types: number;
    total_detections: number;
  }

  interface RecentActivities {
    confidence: number;
    quality: number;
    freq: number;
    type: string;
    peak_power: number;
    duration: number;
    signal_quality_index?: number;
    snr: number;
    timestamp: string;
    quality_color: string;
  }
}

// 👇 This line is important to make the file a module but still allow global declarations
export {};
