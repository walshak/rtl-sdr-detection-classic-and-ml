"use client";

import { useForm } from "react-hook-form";
import FormField from "../common/FormField";
import { toast } from "react-toastify";
import { useState } from "react";
import { Spinner } from "../common/Spinner";
import SelectField from "../common/SelectField";

function SignUpForm() {
  const [loading, setLoading] = useState(false);
  // const router = useRouter();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SignUpFormData>();

  const onSubmit = async (data: SignUpFormData) => {
    try {
      setLoading(true);
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        toast.error(errorData.message);
      } else {
        toast.success("Account created successful!");
      }
    } catch (error) {
      toast.error("An unexpected error occurred. Please try again.");
    } finally {
      setLoading(false);
    }
  };
  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="grid space-y-2 col-auto">
        <h1 className="text-xl text-gray-300 text-center font-bold mb-4">
          {" "}
          Create New Account
        </h1>
        <div className="flex flex-col gap-5 px-4">
          <FormField
            type="text"
            placeholder="Name"
            name="name"
            register={register}
            error={errors.name}
          />
          <FormField
            type="email"
            placeholder="Email"
            name="email"
            register={register}
            error={errors.email}
          />

          <FormField
            type="password"
            placeholder="Password"
            name="password"
            register={register}
            error={errors.password}
          />

          <SelectField
            name="role"
            register={register}
            error={errors.role}
            options={[
              { label: "Operator", value: "OPERATOR" },
              { label: "Admin", value: "ADMIN" },
            ]}
          />
        </div>
        <div className="flex justify-center">
          {" "}
          <button
            className="bg-defaultBlue px-6 py-2   text-white rounded-lg hover:bg-blue-700 transition"
            type="submit"
          >
            {loading ? <Spinner /> : "Create Account"}
          </button>
        </div>
      </div>
    </form>
  );
}

export default SignUpForm;
