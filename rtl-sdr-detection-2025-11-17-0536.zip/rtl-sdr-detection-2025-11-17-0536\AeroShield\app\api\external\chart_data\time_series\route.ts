import { NextResponse, NextRequest } from "next/server";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const query = Object.fromEntries(url.searchParams.entries());
    const response = await fetch(
      `${process.env.API_BASE_URL}/chart_data/time_series?${new URLSearchParams(query).toString()}`,
    );
    const data = await response.json();
    return NextResponse.json({
      message: "Time series data successfully retrieved",
      data: data,
      success: true,
    });
  } catch (error) {
    return NextResponse.json(
      {
        message: `Error retrieving time series data, pls try again later`,
        error: (error as Error).message,
      },
      { status: 500 },
    );
  }
}
