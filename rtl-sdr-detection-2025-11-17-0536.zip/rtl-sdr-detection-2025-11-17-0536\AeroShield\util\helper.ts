import { AntennaData, Detection, SignalData } from "@/types/signal";

// Generate simulated signal data
export const generateSignal = (
  freqMin: number,
  freqMax: number,
  type: "VHF" | "UHF" | "GSM" | "UAV",
  antenna: AntennaData,
): SignalData => {
  const freq: number = Math.random() * (freqMax - freqMin) + freqMin;
  const strength: number = -120 + Math.random() * 90;
  const snr: number = 5 + Math.random() * 35;
  // Bearing relative to antenna's direction ± half coverageAngle
  const halfAngle = antenna.coverage_angle / 2;
  const bearing =
    antenna.direction - halfAngle + Math.random() * antenna.coverage_angle;

  const distance: number =
    Math.random() * (antenna.coverage_radius - 0.1) + 0.1; // stay within coverage radius
  // Calculate actual lat/lng based on bearing and distance
  const R: number = 6371; // Earth's radius in km
  const bearingRad: number = (bearing * Math.PI) / 180;
  const lat1: number = (antenna.lat * Math.PI) / 180;
  const lng1: number = (antenna.lng * Math.PI) / 180;

  const lat2: number = Math.asin(
    Math.sin(lat1) * Math.cos(distance / R) +
      Math.cos(lat1) * Math.sin(distance / R) * Math.cos(bearingRad),
  );

  const lng2: number =
    lng1 +
    Math.atan2(
      Math.sin(bearingRad) * Math.sin(distance / R) * Math.cos(lat1),
      Math.cos(distance / R) - Math.sin(lat1) * Math.sin(lat2),
    );

  return {
    id: Math.random(),
    frequency: parseFloat(freq.toFixed(2)),
    strength: strength.toFixed(1),
    snr: snr.toFixed(1),
    type,
    modulation: Math.random() > 0.5 ? "FM" : "AM",
    bandwidth: (10 + Math.random() * 40).toFixed(1),
    duration: Math.floor(Math.random() * 300),
    bearing: parseFloat(bearing.toFixed(1)),
    distance: parseFloat(distance.toFixed(2)),
    lat: (lat2 * 180) / Math.PI,
    lng: (lng2 * 180) / Math.PI,
    timestamp: new Date(),
  };
};

export const generateRealSignal = (
  detection: Detection,
  type: "VHF" | "UHF" | "GSM" | "UAV",
  modulation: "FM" | "AM",
  antenna: AntennaData,
): SignalData => {
  // const strength: number = -120 + Math.random() * 90;

  // Bearing relative to antenna's direction ± half coverageAngle
  const halfAngle = antenna.coverage_angle / 2;
  const bearing =
    antenna.direction - halfAngle + Math.random() * antenna.coverage_angle;

  const distance: number =
    Math.random() * (antenna.coverage_radius - 0.1) + 0.1; // stay within coverage radius
  // Calculate actual lat/lng based on bearing and distance
  const R: number = 6371; // Earth's radius in km
  const bearingRad: number = (bearing * Math.PI) / 180;
  const lat1: number = (antenna.lat * Math.PI) / 180;
  const lng1: number = (antenna.lng * Math.PI) / 180;

  const lat2: number = Math.asin(
    Math.sin(lat1) * Math.cos(distance / R) +
      Math.cos(lat1) * Math.sin(distance / R) * Math.cos(bearingRad),
  );

  const lng2: number =
    lng1 +
    Math.atan2(
      Math.sin(bearingRad) * Math.sin(distance / R) * Math.cos(lat1),
      Math.cos(distance / R) - Math.sin(lat1) * Math.sin(lat2),
    );

  return {
    id: detection.id,
    frequency: parseFloat((detection.freq / 1000000).toFixed(2)),
    strength: detection.peak_power.toFixed(1),
    snr: detection.snr.toFixed(1),
    type,
    modulation,
    bandwidth: String((detection.bandwidth / 1000).toFixed(1)),
    duration: Math.floor(Math.random() * 300),
    bearing: parseFloat(bearing.toFixed(1)),
    distance: parseFloat(distance.toFixed(2)),
    lat: (lat2 * 180) / Math.PI,
    lng: (lng2 * 180) / Math.PI,
    timestamp: new Date(detection.timestamp),
  };
};

export const generateWaterfallLine = (): number[] => {
  const line: number[] = [];
  for (let i = 0; i < 100; i++) {
    line.push(Math.random() * 100);
  }
  return line;
};

export const generateAntenna = (
  startLat: number,
  startLng: number,
  distanceKm: number,
  count: number,
  bearing = 90,
) => {
  const R = 6371; // Earth radius in km
  const antennas: AntennaData[] = [];
  const brng = (bearing * Math.PI) / 180;

  for (let i = 0; i < count; i++) {
    const d = distanceKm * i;
    const lat1 = (startLat * Math.PI) / 180;
    const lng1 = (startLng * Math.PI) / 180;

    const lat2 = Math.asin(
      Math.sin(lat1) * Math.cos(d / R) +
        Math.cos(lat1) * Math.sin(d / R) * Math.cos(brng),
    );

    const lng2 =
      lng1 +
      Math.atan2(
        Math.sin(brng) * Math.sin(d / R) * Math.cos(lat1),
        Math.cos(d / R) - Math.sin(lat1) * Math.sin(lat2),
      );

    const coverageAngles = [120, 180, 240, 360];
    const coverageAngle =
      coverageAngles[Math.floor(Math.random() * coverageAngles.length)];
    antennas.push({
      id: i + 1,
      name: `Geofence ${i + 1}`,
      lat: +(lat2 * (180 / Math.PI)).toFixed(6),
      lng: +(lng2 * (180 / Math.PI)).toFixed(6),
      coverage_radius: 2, // example: 2 km
      direction: bearing,
      size: Math.floor(Math.random() * 10 + 20), // size between 30 and 50
      coverage_angle: coverageAngle,
      // type: ["VHF", "UHF", "GSM", "UAV"][i % 4] as
      //   | "VHF"
      //   | "UHF"
      //   | "GSM"
      //   | "UAV",
      status: ["active", "inactive", "maintenance"][i % 3] as
        | "active"
        | "inactive"
        | "maintenance",
    });
  }

  return antennas;
};

export const generateRecentActivities = (n: number) => {
  const activities = Array.from({ length: n }, (_, i) => {
    const descriptions = [
      `Antenna ${Math.floor(Math.random() * 10) + 1} reported new signal.`,
      ,
      `Antenna ${Math.floor(Math.random() * 10) + 1} deployed - Range: 1000m, Coverage: 360 new signal.`,
      `Antenna ${Math.floor(Math.random() * 10) + 1} deployed - Range: 10000m, Coverage: 360 new signal.`,
    ];
    return {
      id: i + 1,
      antenna_name: `Antenna ${Math.floor(Math.random() * 10) + 1}`,
      activity_type: ["deployed", "updated", "removed"][
        Math.floor(Math.random() * 3)
      ],
      description:
        descriptions[Math.floor(Math.random() * 4)] ||
        `Antenna ${Math.floor(Math.random() * 10) + 1} reported new signal.`,
      timestamp: new Date(Date.now() - Math.floor(Math.random() * 10000000)),
    };
  });
  return activities;
};

export function safeFixed(value: number, decimals = 2) {
  if (value === undefined || value === null) return "N/A";
  const num = Number(value);
  if (Number.isNaN(num)) return "N/A";
  return num.toFixed(decimals);
}

export function safeFreq(freq: number) {
  if (freq === undefined || freq === null || isNaN(freq)) return "N/A";
  return (freq / 1e6).toFixed(3);
}

export function formatTimestamp(timestamp: string) {
  return new Date(timestamp).toLocaleString();
}

export const getCountByLabel = (
  arr: { label: string; count: number }[],
  label: string,
) => {
  const found = arr.find((item) => item.label === label);
  return found ? found.count : 0; // or 0
};

export const getAntennaByName = (name: string, antennas: AntennaData[]) => {
  return antennas.find((antenna) => antenna.name === name);
};
