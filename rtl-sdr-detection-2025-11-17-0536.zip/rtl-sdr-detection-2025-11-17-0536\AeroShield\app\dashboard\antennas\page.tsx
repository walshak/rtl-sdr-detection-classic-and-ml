import Antenna from "@/components/Antenna";

export default function AntenasDashboardPage() {
  return <Antenna />;
}
