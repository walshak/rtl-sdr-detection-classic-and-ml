import Sidebar from "@/components/Sidebar";
import { SidebarProvider } from "@/hooks/SidebarContex";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <SidebarProvider>
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-4 w-full min-h-screen">{children}</main>
      </div>
    </SidebarProvider>
  );
}
