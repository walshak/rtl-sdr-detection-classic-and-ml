import { useEffect } from "react";
import { useMap } from "react-leaflet";

export const MapResizer: React.FC<{
  largeView: boolean;
  isSidebarOpen?: boolean;
}> = ({ largeView, isSidebarOpen }) => {
  const map = useMap();

  useEffect(() => {
    setTimeout(() => {
      map.invalidateSize();
    }, 300); // give time for layout to settle
  }, [largeView, map, isSidebarOpen]);

  return null; // nothing to render
};
