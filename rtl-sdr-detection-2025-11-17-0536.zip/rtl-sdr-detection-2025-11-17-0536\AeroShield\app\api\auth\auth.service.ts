import { prisma } from "@/lib/prisma";
import { Prisma } from "@prisma/client";

export class AuthService {
  async findUserByEmail(email: string) {
    // Find user
    const user = await prisma.user.findUnique({
      where: { email },
    });
    return user;
  }

  async createUser(data: Prisma.UserCreateInput) {
    const user = await prisma.user.create({
      data,
    });
    return user;
  }

  async findUserById(id: string) {
    const user = await prisma.user.findUnique({
      where: { id },
    });
    return user;
  }

  async updateUser(id: string, data: Prisma.UserUpdateInput) {
    const user = await prisma.user.update({
      where: { id },
      data,
    });
    return user;
  }
}
