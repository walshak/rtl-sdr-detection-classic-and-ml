import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  Polyline,
  Circle,
  Polygon,
} from "react-leaflet";
import React, { useEffect } from "react";
import { LatLngExpression } from "leaflet";
import "leaflet/dist/leaflet.css";
import "leaflet-defaulticon-compatibility/dist/leaflet-defaulticon-compatibility.css";
import "leaflet-defaulticon-compatibility";
import { AntennaData, SignalData } from "@/types/signal";
import { MapUpdater } from "./MapUpdater";
import { MapResizer } from "./MapResizer";
import { createCustomIcon } from "./icons/CustomIcon";
import { createAntennaIcon } from "./icons/AntennaIcon";

interface SignalMapProps {
  detectedObjects: SignalData[];
  selectedObject: SignalData | null;
  onSelectObject: (obj: SignalData) => void;
  antennas: AntennaData[];
  selectedAntenna: AntennaData | null;
  onSelectAntenna: (antenna: AntennaData) => void;
  largeView?: boolean;
  setLargeView?: (large: boolean) => void;
  isSidebarOpen?: boolean;
  mapCenter?: LatLngExpression;
}

const SignalMap = ({
  detectedObjects,
  selectedObject,
  onSelectObject,
  antennas,
  selectedAntenna,
  onSelectAntenna,
  largeView = false,
  isSidebarOpen,
  setLargeView,
  mapCenter = [9.0579, 7.4951],
}: SignalMapProps) => {
  // Calculate sector polygon for directional coverage
  const calculateSectorPolygon = (
    lat: number,
    lng: number,
    radius: number,
    direction: number,
    angle: number,
  ): [number, number][] => {
    const points: [number, number][] = [];
    const startAngle = direction - angle / 2;
    const endAngle = direction + angle / 2;
    const segments = 40;

    points.push([lat, lng]);

    for (let i = 0; i <= segments; i++) {
      const currentAngle =
        startAngle + (endAngle - startAngle) * (i / segments);
      const rad = (currentAngle * Math.PI) / 180;

      const R = 6371;
      const lat1 = (lat * Math.PI) / 180;
      const lng1 = (lng * Math.PI) / 180;

      const lat2 = Math.asin(
        Math.sin(lat1) * Math.cos(radius / R) +
          Math.cos(lat1) * Math.sin(radius / R) * Math.cos(rad),
      );

      const lng2 =
        lng1 +
        Math.atan2(
          Math.sin(rad) * Math.sin(radius / R) * Math.cos(lat1),
          Math.cos(radius / R) - Math.sin(lat1) * Math.sin(lat2),
        );

      points.push([(lat2 * 180) / Math.PI, (lng2 * 180) / Math.PI]);
    }

    points.push([lat, lng]);
    return points;
  };

  // Antenna colors based on type
  // const getAntennaColor = (type: "VHF" | "UHF" | "GSM" | "UAV") => {
  //   switch (type) {
  //     case "VHF":
  //       return "#22c55e"; // green
  //     case "UHF":
  //       return "#a855f7"; // purple
  //     case "GSM":
  //       return "#06b6d4"; // cyan
  //     case "UAV":
  //       return "#f59e0b"; // yellow
  //   }
  // };

  // Add pulse animation to document head
  useEffect(() => {
    if (!document.getElementById("marker-animation")) {
      const style = document.createElement("style");
      style.id = "marker-animation";
      style.innerHTML = `
        @keyframes pulse {
          0% {
            opacity: 1;
            transform: translate(-50%, -50%) scale(1);
          }
          100% {
            opacity: 0;
            transform: translate(-50%, -50%) scale(2);
          }
        }
      `;
      document.head.appendChild(style);
    }
  }, []);

  return (
    <MapContainer
      center={mapCenter as LatLngExpression}
      zoom={12}
      scrollWheelZoom={true}
      style={{ height: "100%", width: "100%" }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />

      {/* Render All Antennas with Coverage */}
      {antennas.map((antenna) => {
        const isSelected = selectedAntenna?.id === antenna.id;
        const color = "#f87171"; // Using a fixed color for antennas

        // Calculate coverage sector
        const sectorPoints = calculateSectorPolygon(
          antenna.lat,
          antenna.lng,
          antenna.coverage_radius,
          antenna.direction,
          antenna.coverage_angle,
        );

        const opacity = antenna.status === "active" ? 0.2 : 0.08;
        const strokeOpacity = isSelected
          ? 0.9
          : antenna.status === "active"
            ? 0.5
            : 0.3;

        return (
          <React.Fragment key={antenna.id}>
            {/* Coverage Sector (Directional) */}
            <Polygon
              positions={sectorPoints}
              pathOptions={{
                color: color,
                fillColor: color,
                fillOpacity: opacity,
                weight: isSelected ? 3 : 2,
                opacity: strokeOpacity,
                dashArray:
                  antenna.status === "maintenance" ? "10, 5" : undefined,
              }}
              eventHandlers={{
                click: () => onSelectAntenna(antenna),
              }}
            />

            {/* Full Coverage Circle (lighter, for reference) */}
            <Circle
              center={[antenna.lat, antenna.lng]}
              radius={antenna.coverage_radius * 1000}
              pathOptions={{
                color: color,
                weight: 1,
                opacity: 0.15,
                fillOpacity: 0.05,
                dashArray: "5, 10",
              }}
            />

            {/* Direction indicator line (when selected) */}
            {isSelected && (
              <Polyline
                positions={[
                  [antenna.lat, antenna.lng],
                  sectorPoints[Math.floor(sectorPoints.length / 2)],
                ]}
                pathOptions={{
                  color: color,
                  weight: 3,
                  opacity: 0.9,
                  dashArray: "8, 4",
                }}
              />
            )}

            {/* Antenna Marker */}
            <Marker
              position={[antenna.lat, antenna.lng]}
              icon={createAntennaIcon(antenna, isSelected)}
              eventHandlers={{
                click: () => onSelectAntenna(antenna),
              }}
              zIndexOffset={1000}
            >
              <Popup>
                <div
                  style={{
                    fontFamily: "monospace",
                    fontSize: "11px",
                    minWidth: "180px",
                  }}
                >
                  <b style={{ fontSize: "13px", color: color }}>
                    {antenna.name}
                  </b>
                  <br />
                  <hr
                    style={{
                      margin: "4px 0",
                      border: "none",
                      borderTop: `1px solid ${color}`,
                    }}
                  />
                  {/* <b>Type:</b> {antenna.type}
                  <br /> */}
                  <b>Status:</b>{" "}
                  <span
                    style={{
                      color:
                        antenna.status === "active"
                          ? "#22c55e"
                          : antenna.status === "maintenance"
                            ? "#eab308"
                            : "#ef4444",
                    }}
                  >
                    {antenna.status.toUpperCase()}
                  </span>
                  <br />
                  <b>Direction:</b> {antenna.direction}°<br />
                  <b>Coverage Angle:</b> {antenna.coverage_angle}°<br />
                  <b>Radius:</b> {antenna.coverage_radius.toFixed(2)} km
                  <br />
                  <b>Location:</b>
                  <br />
                  &nbsp;&nbsp;{antenna.lat.toFixed(6)}, {antenna.lng.toFixed(6)}
                </div>
              </Popup>
            </Marker>
          </React.Fragment>
        );
      })}

      {/* Signal Markers and Bearing Lines */}
      {detectedObjects.map((obj) => {
        const isSelected = selectedObject?.id === obj.id;
        const color = obj.type === "VHF" ? "#22c55e" : "#a855f7";
        const detectingAntenna = antennas.find(
          (a) => a.id === obj.detectedByAntennaId,
        );

        return (
          <React.Fragment key={obj.id}>
            {/* Bearing Line */}
            {detectingAntenna && (
              <>
                <Polyline
                  positions={[
                    [detectingAntenna.lat, detectingAntenna.lng],
                    [obj.lat, obj.lng],
                  ]}
                  pathOptions={{
                    color: color,
                    weight: isSelected ? 3 : 2,
                    opacity: isSelected ? 0.7 : 0.4,
                    dashArray: "5, 10",
                  }}
                />
                <MapUpdater
                  center={
                    selectedObject
                      ? [selectedObject.lat, selectedObject.lng]
                      : [detectingAntenna.lat, detectingAntenna.lng]
                  }
                />
              </>
            )}

            {/* Signal Marker */}
            <Marker
              position={[obj.lat, obj.lng]}
              icon={createCustomIcon(obj.type, isSelected)}
              eventHandlers={{
                click: () => {
                  onSelectObject(obj);
                  setLargeView && setLargeView(false);
                },
              }}
            >
              <Popup>
                <div className="font-mono text-xs">
                  <b>{obj.type} Signal</b>
                  <br />
                  <b>Freq:</b> {obj.frequency.toFixed(2)} MHz
                  <br />
                  <b>Strength:</b> {obj.strength} dBm
                  <br />
                  <b>Bearing:</b> {obj.bearing}°<br />
                  <b>Distance:</b> {obj.distance} km
                  <br />
                  <b>Detected By:</b> {detectingAntenna?.name || "Unknown"}
                  <br />
                  <b>Location:</b> {obj.lat.toFixed(6)}, {obj.lng.toFixed(6)}
                </div>
              </Popup>
            </Marker>

            {/* Selection Circle */}
            {isSelected && (
              <Circle
                center={[obj.lat, obj.lng]}
                radius={50}
                pathOptions={{
                  color: color,
                  fillColor: color,
                  fillOpacity: 0.1,
                }}
              />
            )}
          </React.Fragment>
        );
      })}

      {/* Resize helper component */}
      <MapResizer largeView={largeView} isSidebarOpen={isSidebarOpen} />
    </MapContainer>
  );
};

export default SignalMap;
