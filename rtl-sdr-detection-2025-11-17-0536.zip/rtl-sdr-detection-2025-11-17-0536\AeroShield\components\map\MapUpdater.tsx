import { useEffect } from "react";
import { useMap } from "react-leaflet";

export const MapUpdater: React.FC<{ center: [number, number] }> = ({
  center,
}) => {
  const map = useMap();
  useEffect(() => {
    map.setView(center, map.getZoom());
  }, [center, map]);
  return null;
};

//  const MapUpdater: React.FC<{ center: [number, number]; zoom?: number }> = ({
//    center,
//    zoom,
//  }) => {
//    const map = useMap();
//    useEffect(() => {
//      if (zoom) {
//        map.setView(center, zoom, { animate: true });
//      } else {
//        map.panTo(center, { animate: true });
//      }
//    }, [center, zoom, map]);
//    return null;
//  };
