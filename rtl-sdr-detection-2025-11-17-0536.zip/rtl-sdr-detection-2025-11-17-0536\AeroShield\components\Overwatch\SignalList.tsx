import { SignalData } from "@/types/signal";
import { Radio } from "lucide-react";

interface SignalListProps {
  signals: SignalData[];
  title: string;
  color: string;
  setLargeView?: (large: boolean) => void;
  setSelectedObject: (obj: SignalData) => void;
}

export const SignalList: React.FC<SignalListProps> = ({
  signals,
  title,
  color,
  setSelectedObject,
  setLargeView,
}) => (
  <div className="bg-gray-900 p-4 rounded-lg border border-gray-700">
    <h3
      className={`text-${color}-400 text-sm font-semibold mb-3 flex items-center gap-2`}
    >
      <Radio size={16} />
      {title}
    </h3>
    <div className="space-y-2 max-h-48 overflow-y-auto">
      {signals.length === 0 ? (
        <div className="text-gray-500 text-xs">No active signals</div>
      ) : (
        signals.map((signal) => (
          <div
            key={signal.id}
            className="bg-gray-800 p-2 rounded text-xs border border-gray-700 cursor-pointer hover:border-cyan-500/50 transition-colors"
            onClick={() => {
              setSelectedObject(signal);
              setLargeView?.(false);
            }}
          >
            <div className="flex justify-between items-start mb-1">
              <span className={`text-${color}-400 font-mono font-semibold`}>
                {signal.frequency.toFixed(2)} MHz
              </span>
              <span className="text-gray-400 text-xs">
                {signal.bearing}° / {signal.distance}km
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-gray-400">
              <div>{signal.strength} dBm</div>
              <div>SNR: {signal.snr}</div>
              <div>{signal.modulation}</div>
            </div>
          </div>
        ))
      )}
    </div>
  </div>
);
