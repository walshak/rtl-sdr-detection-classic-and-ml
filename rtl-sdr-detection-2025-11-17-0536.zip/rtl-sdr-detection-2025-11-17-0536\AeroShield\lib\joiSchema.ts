import Joi from "joi";

export const createUserSchema = Joi.object({
  name: Joi.string().min(3).max(50).required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(6).required(),
});

export const loginSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required(),
});

export const createAntennaScehma = Joi.object({
  name: Joi.string().required(),
  lat: Joi.number().required(),
  lng: Joi.number().required(),
  coverage_radius: Joi.number().required(),
  direction: Joi.number().required(),
  size: Joi.number().required(),
  coverage_angle: Joi.number().required(),
  status: Joi.string()
    .valid("active", "inactive", "maintenance")
    .default("active"),
});

export const updateAntennaSchema = Joi.object({
  name: Joi.string().optional(),
  lat: Joi.number().optional(),
  lng: Joi.number().optional(),
  coverage_radius: Joi.number().optional(),
  direction: Joi.number().optional(),
  size: Joi.number().optional(),
  coverage_angle: Joi.number().optional(),
  status: Joi.string().valid("active", "inactive", "maintenance").optional(),
});

export const createReportSchema = Joi.object({
  antenna_name: Joi.string().required(),
  message: Joi.string().required(),
  severity: Joi.string().valid("low", "medium", "high").required(),
  timestamp: Joi.date().required(),
});
