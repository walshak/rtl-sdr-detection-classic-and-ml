export default function SettingsDashboardPage() {
  return (
    <div className="flex justify-center">
      <h2 className="font-semibold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent text-3xl">
        Settings Page
      </h2>
    </div>
  );
}
