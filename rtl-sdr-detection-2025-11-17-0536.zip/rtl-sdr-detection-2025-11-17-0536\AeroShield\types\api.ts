export type RouteContext = { params: Promise<{ id: string }> };
