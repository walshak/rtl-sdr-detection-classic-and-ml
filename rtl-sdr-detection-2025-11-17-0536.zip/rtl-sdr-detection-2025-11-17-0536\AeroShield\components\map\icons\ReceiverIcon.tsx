import L from "leaflet";
import ReactDOMServer from "react-dom/server";

import { TbAntenna } from "react-icons/tb";

export const antennaIcon = L.divIcon({
  className: "receiver-marker",
  html: ReactDOMServer.renderToString(
    <TbAntenna
      style={{
        color: "#06b6d4",
        fontSize: "24px",
        filter: "drop-shadow(0 0 6px rgba(34,197,94,0.5))",
      }}
    />
  ),
  iconSize: [24, 24],
  iconAnchor: [12, 24],
});
