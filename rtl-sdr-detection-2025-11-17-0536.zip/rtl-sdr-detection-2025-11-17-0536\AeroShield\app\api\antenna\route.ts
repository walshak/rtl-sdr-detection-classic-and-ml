import { NextRequest, NextResponse } from "next/server";
import { AntennaService } from "./antenna.service";
import { validateDto } from "@/util/validateDto";
import { createAntennaScehma } from "@/lib/joiSchema";

const antennaService = new AntennaService();

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const validateError = await validateDto(createAntennaScehma)(body);
    if (validateError) return validateError;
    const antenna = await antennaService.create(body);

    return NextResponse.json(
      {
        message: "Antenna created successfully",
        success: true,
        data: antenna,
      },
      { status: 201 },
    );
  } catch (error) {
    return NextResponse.json(
      {
        message: `Error creating antenna pls try again later`,
        error: (error as Error).message,
      },
      { status: 500 },
    );
  }
}

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const query = Object.fromEntries(url.searchParams.entries());

    const antennas = await antennaService.findAll({ ...query });
    return NextResponse.json(
      {
        message: "antennas successfully retrieved",
        success: true,
        data: antennas,
      },
      { status: 200 },
    );
  } catch (error) {
    return NextResponse.json(
      {
        message: "An error occured while fetching antennas",
        success: false,
        error: (error as Error).message,
      },
      { status: 500 },
    );
  }
}
