import L from "leaflet";

export const createCustomIcon = (
  type: "VHF" | "UHF" | "GSM" | "UAV",
  isSelected: boolean
) => {
  const color =
    type === "VHF"
      ? " #22c55e"
      : type === "UHF"
        ? "#a855f7"
        : type === "GSM"
          ? "#f59e0b"
          : "#f59e0b";
  const size = isSelected ? 16 : 12;

  return L.divIcon({
    className: "custom-signal-marker",
    html: `
          <div style="position: relative;">
            <div style="
              background: ${color};
              width: ${isSelected ? "16px" : "12px"};
              height: ${isSelected ? "16px" : "12px"};
              border-radius: 50%;
              border: 2px solid white;
              box-shadow: 0 0 ${isSelected ? "15px" : "10px"} ${color};
              transition: all 0.3s;
            "></div>
            ${
              isSelected
                ? `
              <div style="
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 30px;
                height: 30px;
                border: 2px solid ${color};
                border-radius: 50%;
                animation: pulse 1.5s infinite;
              "></div>
            `
                : ""
            }
          </div>
        `,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
};
