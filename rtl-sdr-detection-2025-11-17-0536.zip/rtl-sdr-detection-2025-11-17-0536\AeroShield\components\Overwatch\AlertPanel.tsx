import { Alert } from "@/types/signal";
import { AlertTriangle } from "lucide-react";

interface AlertPanelProps {
  alerts: Alert[];
}

export const AlertPanel: React.FC<AlertPanelProps> = ({ alerts }) => {
  return (
    <div className="bg-gray-900 p-4 rounded-lg border border-gray-700">
      <h3 className="text-red-400 text-sm font-semibold mb-3 flex items-center gap-2">
        <AlertTriangle size={16} />
        System Alerts
      </h3>
      <div className="space-y-2 max-h-48 overflow-y-auto">
        {alerts.length === 0 ? (
          <div className="text-gray-500 text-xs">No alerts</div>
        ) : (
          alerts.map((alert) => (
            <div
              key={alert.id}
              className={`p-2 rounded text-xs border ${
                alert.severity === "high"
                  ? "bg-red-500/10 border-red-500/30 text-red-300"
                  : "bg-yellow-500/10 border-yellow-500/30 text-yellow-300"
              }`}
            >
              <div className="font-semibold mb-1">{alert.message}</div>
              <div className="text-xs opacity-70">{alert.time}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
