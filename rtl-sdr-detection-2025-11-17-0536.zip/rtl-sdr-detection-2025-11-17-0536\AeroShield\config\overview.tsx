import { SignalData } from "@/types/signal";
import { Activity, Radio, AlertTriangle } from "lucide-react";

export const generateMetricList = (
  vhfLength: number,
  uhfLength: number,
  gsmLength: number,
  alertLength: number,
) => {
  return [
    {
      label: "Detected Objects",
      value: vhfLength + uhfLength + gsmLength,
      icon: Activity,
      color: "cyan",
      trend: true,
    },
    {
      label: "VHF Signals",
      value: vhfLength,
      icon: Radio,
      color: "green",
    },
    {
      label: "UHF Signals",
      value: uhfLength,
      icon: Radio,
      color: "purple",
    },
    {
      label: "GSM Signals",
      value: gsmLength,
      icon: Radio,
      color: "cyan",
    },
    {
      label: "Alerts",
      value: alertLength,
      icon: AlertTriangle,
      color: "red",
    },
  ];
};

export const generateWaterfallList = (
  waterfallVHF: number[][],
  waterfallUHF: number[][],
  waterfallGSM: number[][],
  time: Date,
) => {
  return [
    {
      data: waterfallVHF,
      title: "VHF Spectrum Waterfall",
      freqRange: "30 - 300 MHz",
      time: time,
    },
    {
      data: waterfallUHF,
      title: "UHF Spectrum Waterfall",
      freqRange: "300 - 3000 MHz",
      time: time,
    },
    {
      data: waterfallGSM,
      title: "GSM Spectrum Waterfall",
      freqRange: "900 - 1800 MHz",
      time: time,
    },
  ];
};

export const generateSignalList = (
  vhfSignals: SignalData[],
  uhfSignals: SignalData[],
  gsmSignals: SignalData[],
) => {
  return [
    { signal: vhfSignals, title: "VHF Detected Signals", color: "green" },
    { signal: uhfSignals, title: "UHF Detected Signals", color: "purple" },
    { signal: gsmSignals, title: "GSM Detected Signals", color: "cyan" },
  ];
};
