"use client";

import { AntennaData } from "@/types/signal";
// import { generateAntenna } from "@/util/helper";
import { useEffect, useState } from "react";
import MuiTableComponent from "../table/tableComp";
import { AntennaColumns } from "../table/column";
import { useSidebar } from "@/hooks/SidebarContex";
import { FaPlus } from "react-icons/fa6";
import AddAntennaModal from "../modals/add-antenna-modal";

export default function Antenna() {
  const [loading, setLoading] = useState<boolean>(true);
  const [antennas, setAntennas] = useState<AntennaData[]>([]);
  const { isSidebarOpen } = useSidebar();
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const fetchAntennaData = async () => {
      const response = await fetch("/api/antenna");
      if (!response.ok) {
        setLoading(false);
        throw new Error("Failed to fetch antenna data");
      }
      const data = await response.json();
      setAntennas(data.data.data);
      setLoading(false);
    };
    fetchAntennaData();
  }, []);

  const handleAddAntenna = (antenna: AntennaData) => {
    setAntennas((prev) => [...prev, antenna]);
  };
  return (
    <div className={`flex flex-col justify-center  p-4`}>
      <AddAntennaModal
        antennasLength={antennas.length}
        modalOpen={isModalOpen}
        setModalOpen={setIsModalOpen}
        newAntenna={handleAddAntenna}
      />
      <div className="flex justify-between items-center">
        {" "}
        <h2 className="font-semibold   bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent text-3xl">
          Available Antennas
        </h2>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-defaultCyan hover:bg-hoverCyan text-white disabled:bg-gray-700 px-4 py-2 rounded-lg text-sm font-semibold transition-colors"
        >
          <FaPlus /> Add Antenna
        </button>
      </div>

      <section
        className={`mt-4 bg-gray-900 p-4 ${isSidebarOpen ? "w-[1200px]" : ""} rounded-lg border border-cyan-500/30 shadow-lg`}
      >
        <MuiTableComponent
          columns={AntennaColumns}
          loading={loading}
          rows={antennas}
          pageSize={5}
        />
      </section>
    </div>
  );
}
