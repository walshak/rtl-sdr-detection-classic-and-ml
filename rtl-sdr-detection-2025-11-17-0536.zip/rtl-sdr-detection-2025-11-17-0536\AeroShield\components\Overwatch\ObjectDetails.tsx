import { SignalData } from "@/types/signal";
import { Navigation } from "lucide-react";

interface ObjectDetailsProps {
  selectedObject: SignalData | null;
  setSelectedObject: (obj: SignalData | null) => void;
  hide: boolean;
}

export const ObjectDetails: React.FC<ObjectDetailsProps> = ({
  selectedObject,
  setSelectedObject,
  hide,
}) => {
  if (hide) return;
  if (!selectedObject) {
    return (
      <div className="bg-gray-900 p-4 rounded-lg border border-gray-700 flex items-center h-full justify-center ">
        <p className="text-gray-500 text-sm">
          Select an object on the map to view details
        </p>
      </div>
    );
  }

  return (
    <div className="bg-gray-900 p-4 rounded-lg border border-cyan-500/30">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-cyan-400 text-sm font-semibold flex items-center gap-2">
          <Navigation size={16} />
          Object Details
        </h3>
        <button
          onClick={() => setSelectedObject(null)}
          className="text-defaultBlue hover:text-white text-xs"
        >
          ✕
        </button>
      </div>

      <div className="space-y-3">
        <div className="bg-gray-800 p-3 rounded">
          <div className="text-xs text-gray-400 mb-1">Frequency</div>
          <div
            className={`text-lg font-mono font-bold ${
              selectedObject.type === "VHF"
                ? "text-green-400"
                : selectedObject.type === "GSM"
                  ? "text-yellow-500"
                  : "text-purple-400"
            }`}
          >
            {selectedObject.frequency.toFixed(2)} MHz
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="bg-gray-800 p-2 rounded">
            <div className="text-xs text-gray-400">Bearing</div>
            <div className="text-sm font-semibold text-cyan-400">
              {selectedObject.bearing}°
            </div>
          </div>
          <div className="bg-gray-800 p-2 rounded">
            <div className="text-xs text-gray-400">Distance</div>
            <div className="text-sm font-semibold text-cyan-400">
              {selectedObject.distance} km
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="bg-gray-800 p-2 rounded">
            <div className="text-xs text-gray-400">Signal Strength</div>
            <div
              className={`text-sm font-semibold ${
                parseFloat(selectedObject.strength) > -50
                  ? "text-red-400"
                  : parseFloat(selectedObject.strength) > -80
                    ? "text-yellow-400"
                    : "text-green-400"
              }`}
            >
              {selectedObject.strength} dBm
            </div>
          </div>
          <div className="bg-gray-800 p-2 rounded">
            <div className="text-xs text-gray-400">SNR</div>
            <div className="text-sm font-semibold text-white">
              {selectedObject.snr} dB
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="bg-gray-800 p-2 rounded">
            <div className="text-xs text-gray-400">Modulation</div>
            <div className="text-sm font-semibold text-white">
              {selectedObject.modulation}
            </div>
          </div>
          <div className="bg-gray-800 p-2 rounded">
            <div className="text-xs text-gray-400">Bandwidth</div>
            <div className="text-sm font-semibold text-white">
              {selectedObject.bandwidth} kHz
            </div>
          </div>
        </div>

        <div className="bg-gray-800 p-2 rounded">
          <div className="text-xs text-gray-400">GPS Coordinates</div>
          <div className="text-xs font-mono text-white mt-1">
            Lat: {selectedObject.lat.toFixed(6)}
            <br />
            Lng: {selectedObject.lng.toFixed(6)}
          </div>
        </div>

        <div className="bg-gray-800 p-2 rounded">
          <div className="text-xs text-gray-400">First Detected</div>
          <div className="text-xs text-white">
            {selectedObject.timestamp.toLocaleTimeString()}
          </div>
        </div>
      </div>
    </div>
  );
};
