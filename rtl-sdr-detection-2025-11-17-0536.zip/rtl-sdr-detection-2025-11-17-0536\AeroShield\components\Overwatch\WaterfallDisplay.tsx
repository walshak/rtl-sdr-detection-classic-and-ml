interface WaterfallDisplayProps {
  data: number[][];
  title: string;
  freqRange: string;
  time: string;
}
export const WaterfallDisplay: React.FC<WaterfallDisplayProps> = ({
  data,
  title,
  freqRange,
  time,
}) => (
  <div className="bg-gray-900 p-4 rounded-lg border border-cyan-500/30">
    <h3 className="text-cyan-400 text-sm font-semibold mb-2">{title}</h3>
    <div className="text-xs text-gray-400 mb-2">{freqRange}</div>
    <div className="relative h-32 bg-black rounded overflow-hidden">
      {data.map((line, idx) => (
        <div
          key={idx}
          className="flex h-1"
          style={{ opacity: 1 - (idx / data.length) * 0.7 }}
        >
          {line.map((val, i) => (
            <div
              key={i}
              className="flex-1"
              style={{
                backgroundColor:
                  val > 70
                    ? "#ef4444"
                    : val > 40
                      ? "#eab308"
                      : val > 20
                        ? "#22c55e"
                        : "#1e40af",
                height: "100%",
              }}
            />
          ))}
        </div>
      ))}
    </div>
    <div className="flex justify-between text-xs text-gray-500 mt-1">
      <div className="flex flex-col">
        <span>Time ↓</span>
        {time}
      </div>

      <div className="flex flex-col">
        <span>Frequency →</span>
        {freqRange}
      </div>
    </div>
  </div>
);
