/* eslint-disable @typescript-eslint/no-explicit-any */

import { Paper } from "@mui/material";
import {
  DataGrid,
  GridColDef,
  GridRowId,
  GridRowParams,
  GridRowSelectionModel,
} from "@mui/x-data-grid";

type TableComponentProps = {
  columns: GridColDef[];
  rows: any[];
  onSelect?: (selectedRows: any[]) => void;
  pageSize?: number;
  onPageChange?: (model: { page: number; pageSize: number }) => void;
  currentPage?: number; // Optional, used for server-side pagination
  totalRowCount?: number;
  rowHeight?: number;
  loading?: boolean;
  showCheckbox?: boolean;
  headerStyle?: {
    backgroundColor?: string;
    fontWeight?: string | number;
  };
  onRowClick?: (params: GridRowParams) => void;
};

export default function MuiTableComponent({
  columns,
  rows,
  // pageSize,
  // currentPage = 0,
  rowHeight,
  showCheckbox,
  headerStyle,
  onSelect,
  onRowClick,
  onPageChange,
  totalRowCount = rows.length, // Default to rows length if not provided
  loading = false,
}: TableComponentProps) {
  // const [selectedRowIds, setSelectedRowIds] = useState<GridRowId[]>([]);

  // Handle row click
  const handleRowClick = (params: GridRowParams) => {
    if (onRowClick) {
      onRowClick(params);
    }
  };

  const handleSelectionChange = (newSelection: GridRowSelectionModel) => {
    // Convert Set to array of IDs
    const idsSet = newSelection.ids as Set<GridRowId>;
    const normalizedSelection: GridRowId[] = Array.from(idsSet);

    // Get the full row objects using the IDs
    const selectedRowsData = rows.filter((row) =>
      normalizedSelection.includes(row.id),
    );

    onSelect?.(selectedRowsData);
  };

  return (
    <div className="w-full overflow-x-auto">
      <Paper className="w-full min-w-[400px] min-h-[200px] overflow-hidden">
        <div style={{ width: "100%", overflowX: "auto" }}>
          <DataGrid
            rows={rows}
            rowCount={totalRowCount}
            columns={columns}
            paginationMode="server"
            // paginationModel={{
            //   page: currentPage - 1, // Adjust for zero-based index
            //   pageSize: pageSize || 10,
            // }}
            onPaginationModelChange={(model) =>
              onPageChange &&
              onPageChange({ page: model.page + 1, pageSize: model.pageSize })
            }
            pageSizeOptions={[5, 10, 15, 20]}
            checkboxSelection={showCheckbox}
            disableColumnFilter={true}
            disableColumnMenu={true}
            loading={loading}
            disableRowSelectionOnClick={true}
            onRowSelectionModelChange={handleSelectionChange}
            rowHeight={rowHeight}
            onRowClick={handleRowClick}
            sx={{
              border: 0,
              minWidth: "900px",
              height: 500,
              backgroundColor: "#111827",
              color: "white",
              // paddingLeft: 2,
              "& .MuiCheckbox-root.Mui-checked": {
                color: "#e65800 !important", // Replace with your desired color
              },
              "& .MuiDataGrid-columnHeaders": {
                backgroundColor: headerStyle?.backgroundColor ?? "#111827",
                color: "white",
              },
              "& .MuiDataGrid-columnHeaderTitle": {
                fontWeight: headerStyle?.fontWeight ?? "bold",
                color: "white", // Ensure header text is white
              },
              // Fix for header row staying dark
              "& .MuiDataGrid-columnHeader": {
                backgroundColor: headerStyle?.backgroundColor ?? "#111827",
                color: "white",
              },
              "& .MuiDataGrid-row": {
                cursor: `${onRowClick && "pointer"}`, // Always show pointer cursor on rows
                backgroundColor: "#111827", // Set default row background
                "&:hover": {
                  backgroundColor: "#1f2937 !important", // Darker shade on hover instead of white
                },
              },
              // Prevent cells from turning white on hover
              "& .MuiDataGrid-cell": {
                color: "white",
                borderBottom: "1px solid #374151", // Optional: subtle border
              },
              "& .MuiCircularProgress-root": {
                color: "#14199c", // custom spinner color
                width: "60px !important",
                height: "60px !important",
              },
              // Footer (pagination area)
              "& .MuiDataGrid-footerContainer": {
                backgroundColor: "#111827",
                borderTop: "1px solid #222",
                color: "#f5f5f5",
              },

              // Pagination text and controls
              "& .MuiTablePagination-root, & .MuiTablePagination-toolbar, & .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows":
                {
                  color: "#f5f5f5",
                },

              // Dropdown arrow and icons
              "& .MuiSvgIcon-root": {
                color: "#f5f5f5",
              },

              // Page number buttons
              "& .MuiPaginationItem-root": {
                color: "#f5f5f5",
              },
            }}
          />
        </div>
      </Paper>
    </div>
  );
}
